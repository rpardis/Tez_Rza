%% Script neme: EIG.m
clc, clear all, close all,
load('H_Klass.mat')


%%
m_b_M0=cat(3,mA,mB);
m_g_M0=cat(3,mC,mD);
m_X_M0=cat(3,mA,mB,mC,mD);
m_b_M=mean(m_b_M0,3);
m_g_M=mean(m_g_M0,3);
m_X_M=mean(m_X_M0,3);

Ab_M=(m_b_M+m_b_M')/2;Ag_M=(m_g_M+m_g_M')/2;AX_M=(m_X_M+m_X_M')/2;
[ns,~]=size(Ab_M);
Ab_M(1:ns+1:ns*ns)=0;Ag_M(1:ns+1:ns*ns)=0;AX_M(1:ns+1:ns*ns)=0;
Ab_M(Ab_M<0)=0;Ag_M(Ag_M<0)=0;AX_M(AX_M<0)=0;
Gb_M = graph(Ab_M);Gg_M = graph(Ag_M);GX_M = graph(AX_M);
wbcb_M = centrality(Gb_M,'eigenvector');wbcg_M = centrality(Gg_M,'eigenvector');wbcX_M = centrality(GX_M,'eigenvector');
[~,shr_b_M]=sort(wbcb_M,'descend');[~,shr_g_M]=sort(wbcg_M,'descend');[~,shr_X_M]=sort(wbcX_M,'descend');
%%
m_b_D0=cat(3,mE,mF);
m_g_D0=cat(3,mG,mH);
m_X_D0=cat(3,mE,mF,mG,mH);
m_b_D=mean(m_b_D0,3);
m_g_D=mean(m_g_D0,3);
m_X_D=mean(m_X_D0,3);



Ab_D=(m_b_D+m_b_D')/2;Ag_D=(m_g_D+m_g_D')/2;AX_D=(m_X_D+m_X_D')/2;
[ns,~]=size(Ab_D);
Ab_D(1:ns+1:ns*ns)=0;Ag_D(1:ns+1:ns*ns)=0;AX_D(1:ns+1:ns*ns)=0;
Ab_D(Ab_D<0)=0;Ag_D(Ag_D<0)=0;AX_D(AX_D<0)=0;
Gb_D = graph(Ab_D);Gg_D = graph(Ag_D);GX_D = graph(AX_D);
wbcb_D = centrality(Gb_D,'eigenvector');wbcg_D = centrality(Gg_D,'eigenvector');wbcX_D = centrality(GX_D,'eigenvector');
[~,shr_b_D]=sort(wbcb_D,'descend');[~,shr_g_D]=sort(wbcg_D,'descend');[~,shr_X_D]=sort(wbcX_D,'descend');

%%
save('Eigeners.mat','shr_b_M','shr_g_M','shr_X_M','shr_b_D','shr_g_D','shr_X_D')