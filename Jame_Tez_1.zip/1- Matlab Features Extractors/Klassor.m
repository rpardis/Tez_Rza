%% Script neme: Klassor.m
ccc
%% Envoking UCLA Dataset
disp('Set your current Folder to UCLA_Autism.')
% cd C:\Users\Administrator\Documents\MATLAB
ucd=dir('UCLA_Autism');
addpath('UCLA_Autism');
raw=raw_();
% [~,~,raw] = xlsread('Annex.csv');
[lr,~]=size(raw);

%% Renaming
% ASD102_rsfMRI>>ASD102_rsfMRI_connectivity_matrix_file.txt
raw{1,6}='Class';
raw{1,7}='File Name';
for pp=2:lr
    raw{pp,7}=sprintf('%s_connectivity_matrix_file.txt',raw{pp,1});
end
%%

nN=zeros(1,8);
for ii=2:lr
    c1=all(raw{ii,2}=='MRI');
    c2=all(raw{ii,4}=='Boy ');
    c3=all(raw{ii,5}=='TDC');
    if c1&&c2&&c3
        sss=1;
        raw{ii,6}=char(64+sss);
        nN(sss)=nN(sss)+1;
    elseif c1&&c2&&~c3
        sss=2;
        raw{ii,6}=char(64+sss);
        nN(sss)=nN(sss)+1;
    elseif c1&&~c2&&c3
        sss=3;
        raw{ii,6}=char(64+sss);
        nN(sss)=nN(sss)+1;
    elseif c1&&~c2&&~c3
        sss=4;
        raw{ii,6}=char(64+sss);
        nN(sss)=nN(sss)+1;
    elseif ~c1&&c2&&c3
        sss=5;
        raw{ii,6}=char(64+sss);
        nN(sss)=nN(sss)+1;
    elseif ~c1&&c2&&~c3
        sss=6;
        raw{ii,6}=char(64+sss);
        nN(sss)=nN(sss)+1;
    elseif ~c1&&~c2&&c3
        sss=7;
        raw{ii,6}=char(64+sss);
        nN(sss)=nN(sss)+1;
    elseif ~c1&&~c2&&~c3
        sss=8;
        raw{ii,6}=char(64+sss);
        nN(sss)=nN(sss)+1;
    end
end

%% Tabling
ListName=cell(8,1);
for hh=1:8
    ListName{hh,1}=char(64+hh);
end
Class_Population=nN';
disp(table(Class_Population,'RowNames',ListName))

%% Koll Klass
ni=nN*0;
mA=zeros(264,264,nN(1));
mB=zeros(264,264,nN(2));
mC=zeros(264,264,nN(3));
mD=zeros(264,264,nN(4));
mE=zeros(264,264,nN(5));
mF=zeros(264,264,nN(6));
mG=zeros(264,264,nN(7));
mH=zeros(264,264,nN(8));
for ii=2:lr
    pp=load(raw{ii,7});
    k=raw{ii,6};
    switch k
        case 'A'
            q=1;
            ni(q)=ni(q)+1;
            mA(:,:,ni(q))=pp(:,:);
        case 'B'
            q=2;
            ni(q)=ni(q)+1;
            mB(:,:,ni(q))=pp(:,:);
        case 'C'
            q=3;
            ni(q)=ni(q)+1;
            mC(:,:,ni(q))=pp(:,:);
        case 'D'
            q=4;
            ni(q)=ni(q)+1;
            mD(:,:,ni(q))=pp(:,:);
        case 'E'
            q=5;
            ni(q)=ni(q)+1;
            mE(:,:,ni(q))=pp(:,:);
        case 'F'
            q=6;
            ni(q)=ni(q)+1;
            mF(:,:,ni(q))=pp(:,:);
        case 'G'
            q=7;
            ni(q)=ni(q)+1;
            mG(:,:,ni(q))=pp(:,:);
        case 'H'
            q=8;
            ni(q)=ni(q)+1;
            mH(:,:,ni(q))=pp(:,:);
    end
end
mA(isinf(mA))=0;mB(isinf(mB))=0;mC(isinf(mC))=0;mD(isinf(mD))=0;
mE(isinf(mE))=0;mF(isinf(mF))=0;mG(isinf(mG))=0;mH(isinf(mH))=0;
save('H_Klass.mat','mA','mB','mC','mD','mE','mF','mG','mH')

function AA=raw_()
AA={'Network Name'	'Imaging Modality'	'Age'	'Gender'	'Subject Pool'
    'ASD102_rsfMRI'	'MRI'	11.81	'Boy '	'ASD'
    'ASD103_rsfMRI'	'MRI'	13.31	'Boy '	'ASD'
    'ASD104_rsfMRI'	'MRI'	12.99	'Boy '	'ASD'
    'ASD106_rsfMRI'	'MRI'	12.33	'Boy '	'ASD'
    'ASD108_rsfMRI'	'MRI'	9.260	'Girl'	'ASD'
    'ASD111_rsfMRI'	'MRI'	14.59	'Boy '	'ASD'
    'ASD112_rsfMRI'	'MRI'	17.53	'Girl'	'ASD'
    'ASD113B_rsfMRI'	'MRI'	10.28	'Boy '	'ASD'
    'ASD114_rsfMRI'	'MRI'	15.79	'Boy '	'ASD'
    'ASD115_rsfMRI'	'MRI'	12.75	'Boy '	'ASD'
    'ASD116_rsfMRI'	'MRI'	10.91	'Boy '	'ASD'
    'ASD117_rsfMRI'	'MRI'	10.67	'Boy '	'ASD'
    'ASD119_CCN_rsfMRI'	'MRI'	16.47	'Boy '	'ASD'
    'ASD120_rsfMRI'	'MRI'	17.40	'Boy '	'ASD'
    'ASD124_CCN_rsfMRI'	'MRI'	13.08	'Boy '	'ASD'
    'ASD125_rsfMRI'	'MRI'	13.67	'Boy '	'ASD'
    'ASD127_CCN_rsfMRI'	'MRI'	10.04	'Boy '	'ASD'
    'ASD129_CCN_rsfMRI'	'MRI'	14.27	'Boy '	'ASD'
    'ASD130_rsfMRI'	'MRI'	14.96	'Boy '	'ASD'
    'ASD131_rsfMRI'	'MRI'	10.90	'Boy '	'ASD'
    'ASD132_rsfMRI'	'MRI'	14.14	'Girl'	'ASD'
    'ASD133_CCN_rsfMRI'	'MRI'	10.57	'Boy '	'ASD'
    'ASD134_rsfMRI'	'MRI'	11.69	'Boy '	'ASD'
    'ASD138_CCN_rsfMRI'	'MRI'	10.77	'Boy '	'ASD'
    'ASD142_rsfMRI'	'MRI'	13	'Boy '	'ASD'
    'ASD143_rsfMRI'	'MRI'	11.97	'Boy '	'ASD'
    'ASD67B_rsfMRI'	'MRI'	14.57	'Boy '	'ASD'
    'ASD70B_rsfMRI'	'MRI'	17.94	'Boy '	'ASD'
    'ASD73C_rsfMRI'	'MRI'	15.78	'Boy '	'ASD'
    'ASD75B_rsfMRI'	'MRI'	14.11	'Girl'	'ASD'
    'ASD76C_rsfMRI'	'MRI'	16.98	'Boy '	'ASD'
    'ASD82_rsfMRI'	'MRI'	16.56	'Boy '	'ASD'
    'ASD83B_rsfMRI'	'MRI'	11.27	'Boy '	'ASD'
    'ASD87B_rsfMRI'	'MRI'	15.66	'Boy '	'ASD'
    'ASD90B_rsfMRI'	'MRI'	10.41	'Boy '	'ASD'
    'ASD91B_rsfMRI'	'MRI'	11.56	'Girl'	'ASD'
    'ASD92_rsfMRI'	'MRI'	10.54	'Boy '	'ASD'
    'ASD93B_rsfMRI'	'MRI'	15.22	'Boy '	'ASD'
    'ASD95_rsfMRI'	'MRI'	16.87	'Boy '	'ASD'
    'ASD96B_rsfMRI'	'MRI'	14.13	'Girl'	'ASD'
    'ASD97_rsfMRI'	'MRI'	14.74	'Boy '	'ASD'
    'ASD99_rsfMRI'	'MRI'	14.58	'Boy '	'ASD'
    'TD100C_rsfMRI'	'MRI'	12.36	'Boy '	'TDC'
    'TD101B_rsfMRI'	'MRI'	11	'Boy '	'TDC'
    'TD102B_rsfMRI'	'MRI'	11.79	'Boy '	'TDC'
    'TD103B_rsfMRI'	'MRI'	14.44	'Boy '	'TDC'
    'TD105_rsfMRI'	'MRI'	14.80	'Boy '	'TDC'
    'TD107B_rsfMRI'	'MRI'	14.95	'Boy '	'TDC'
    'TD108B_rsfMRI'	'MRI'	13.37	'Boy '	'TDC'
    'TD111B_rsfMRI'	'MRI'	11.07	'Boy '	'TDC'
    'TD112B_rsfMRI'	'MRI'	13.65	'Boy '	'TDC'
    'TD113B_rsfMRI'	'MRI'	17.79	'Boy '	'TDC'
    'TD114_rsfMRI'	'MRI'	11.56	'Boy '	'TDC'
    'TD118_rsfMRI'	'MRI'	13.45	'Girl'	'TDC'
    'TD120_rsfMRI'	'MRI'	15.92	'Boy '	'TDC'
    'TD121_rsfMRI'	'MRI'	14.02	'Boy '	'TDC'
    'TD122_rsfMRI'	'MRI'	11.26	'Girl'	'TDC'
    'TD123_rsfMRI'	'MRI'	17.77	'Boy '	'TDC'
    'TD124_rsfMRI'	'MRI'	14.29	'Boy '	'TDC'
    'TD125_rsfMRI'	'MRI'	11.08	'Boy '	'TDC'
    'TD126_rsfMRI'	'MRI'	12.10	'Boy '	'TDC'
    'TD128_rsfMRI'	'MRI'	13.41	'Boy '	'TDC'
    'TD129_rsfMRI'	'MRI'	12.68	'Boy '	'TDC'
    'TD130B_rsfMRI'	'MRI'	10.96	'Boy '	'TDC'
    'TD131_rsfMRI'	'MRI'	15.74	'Boy '	'TDC'
    'TD132_CCN_rsfMRI'	'MRI'	13.12	'Girl'	'TDC'
    'TD133_CCN_rsfMRI'	'MRI'	10.53	'Boy '	'TDC'
    'TD134_CCN_rsfMRI'	'MRI'	12.65	'Girl'	'TDC'
    'TD135_rsfMRI'	'MRI'	13.85	'Boy '	'TDC'
    'TD136_CCN_rsfMRI'	'MRI'	11.74	'Boy '	'TDC'
    'TD137_rsfMRI'	'MRI'	12.01	'Boy '	'TDC'
    'TD138B_CCN_rsfMRI'	'MRI'	12.15	'Boy '	'TDC'
    'TD139_CCN_rsfMRI'	'MRI'	9.790	'Boy '	'TDC'
    'TD140_CCN_rsfMRI'	'MRI'	11.92	'Boy '	'TDC'
    'TD142_rsfMRI'	'MRI'	13.82	'Girl'	'TDC'
    'TD143_rsfMRI'	'MRI'	9.500	'Boy '	'TDC'
    'TD144_rsfMRI'	'MRI'	11.82	'Boy '	'TDC'
    'TD145_rsfMRI'	'MRI'	12.73	'Girl'	'TDC'
    'TD86C_rsfMRI'	'MRI'	14.88	'Boy '	'TDC'
    'ASD100B_DTI'	'DTI'	9.220	'Boy '	'ASD'
    'ASD101B_DTI'	'DTI'	9.090	'Boy '	'ASD'
    'ASD103B_DTI'	'DTI'	13.51	'Boy '	'ASD'
    'ASD106B_DTI'	'DTI'	12.53	'Boy '	'ASD'
    'ASD108B_DTI'	'DTI'	9.360	'Girl'	'ASD'
    'ASD109B_DTI'	'DTI'	14.65	'Boy '	'ASD'
    'ASD110B_DTI'	'DTI'	8.360	'Girl'	'ASD'
    'ASD111B_DTI'	'DTI'	14.67	'Boy '	'ASD'
    'ASD112B_DTI'	'DTI'	17.71	'Girl'	'ASD'
    'ASD113B_DTI'	'DTI'	10.28	'Boy '	'ASD'
    'ASD114_DTI'	'DTI'	15.79	'Boy '	'ASD'
    'ASD115_DTI'	'DTI'	12.75	'Boy '	'ASD'
    'ASD116B_DTI'	'DTI'	10.91	'Boy '	'ASD'
    'ASD117B_DTI'	'DTI'	10.67	'Boy '	'ASD'
    'ASD118B_DTI'	'DTI'	12.53	'Boy '	'ASD'
    'ASD119_CCN_DTI'	'DTI'	16.47	'Boy '	'ASD'
    'ASD120_DTI'	'DTI'	17.40	'Boy '	'ASD'
    'ASD124_CCN_DTI'	'DTI'	13.08	'Boy '	'ASD'
    'ASD126_CCN_DTI'	'DTI'	11.70	'Boy '	'ASD'
    'ASD127_CCN_DTI'	'DTI'	10.04	'Boy '	'ASD'
    'ASD129B_CCN_DTI'	'DTI'	14.36	'Boy '	'ASD'
    'ASD130_DTI'	'DTI'	14.96	'Boy '	'ASD'
    'ASD131_DTI'	'DTI'	10.90	'Boy '	'ASD'
    'ASD133_CCN_DTI'	'DTI'	10.57	'Boy '	'ASD'
    'ASD134_DTI'	'DTI'	11.69	'Boy '	'ASD'
    'ASD135_CCN_DTI'	'DTI'	14.64	'Boy '	'ASD'
    'ASD142_DTI'	'DTI'	13.10	'Boy '	'ASD'
    'ASD143_DTI'	'DTI'	11.97	'Boy '	'ASD'
    'ASD38D_DTI'	'DTI'	13.76	'Boy '	'ASD'
    'ASD47B_DTI'	'DTI'	11.78	'Boy '	'ASD'
    'ASD62B_DTI'	'DTI'	10.99	'Boy '	'ASD'
    'ASD63B_DTI'	'DTI'	18.18	'Boy '	'ASD'
    'ASD64B_DTI'	'DTI'	13.37	'Boy '	'ASD'
    'ASD67B_DTI'	'DTI'	14.57	'Boy '	'ASD'
    'ASD70B_DTI'	'DTI'	17.94	'Boy '	'ASD'
    'ASD73B_DTI'	'DTI'	15.69	'Boy '	'ASD'
    'ASD75B_DTI'	'DTI'	14.11	'Girl'	'ASD'
    'ASD77_DTI'	'DTI'	10.19	'Boy '	'ASD'
    'ASD78B_DTI'	'DTI'	9.820	'Girl'	'ASD'
    'ASD80B_DTI'	'DTI'	9.990	'Boy '	'ASD'
    'ASD82B_DTI'	'DTI'	16.83	'Boy '	'ASD'
    'ASD83B_DTI'	'DTI'	11.27	'Boy '	'ASD'
    'ASD85B_DTI'	'DTI'	17.97	'Boy '	'ASD'
    'ASD87B_DTI'	'DTI'	15.66	'Boy '	'ASD'
    'ASD88B_DTI'	'DTI'	9.240	'Boy '	'ASD'
    'ASD90B_DTI'	'DTI'	10.41	'Boy '	'ASD'
    'ASD91B_DTI'	'DTI'	11.56	'Girl'	'ASD'
    'ASD92B_DTI'	'DTI'	10.75	'Boy '	'ASD'
    'ASD93B_DTI'	'DTI'	15.22	'Boy '	'ASD'
    'ASD95B_DTI'	'DTI'	17.32	'Boy '	'ASD'
    'ASD99B_DTI'	'DTI'	14.58	'Boy '	'ASD'
    'TD100B_DTI'	'DTI'	11.51	'Boy '	'TDC'
    'TD101_DTI'	'DTI'	10.79	'Boy '	'TDC'
    'TD102B_DTI'	'DTI'	11.79	'Boy '	'TDC'
    'TD103_DTI'	'DTI'	14.29	'Boy '	'TDC'
    'TD104_DTI'	'DTI'	14.86	'Boy '	'TDC'
    'TD105B_DTI'	'DTI'	16.71	'Boy '	'TDC'
    'TD106B_DTI'	'DTI'	8.960	'Girl'	'TDC'
    'TD107B_DTI'	'DTI'	15.04	'Boy '	'TDC'
    'TD108B_DTI'	'DTI'	13.37	'Boy '	'TDC'
    'TD109B_DTI'	'DTI'	11.61	'Boy '	'TDC'
    'TD111B_DTI'	'DTI'	11.07	'Boy '	'TDC'
    'TD112B_DTI'	'DTI'	13.65	'Boy '	'TDC'
    'TD113B_DTI'	'DTI'	17.79	'Boy '	'TDC'
    'TD114B_DTI'	'DTI'	11.66	'Boy '	'TDC'
    'TD116B_DTI'	'DTI'	16.03	'Boy '	'TDC'
    'TD118B_DTI'	'DTI'	13.82	'Girl'	'TDC'
    'TD120B_DTI'	'DTI'	16.16	'Boy '	'TDC'
    'TD122B_DTI'	'DTI'	11.34	'Girl'	'TDC'
    'TD123B_DTI'	'DTI'	17.92	'Boy '	'TDC'
    'TD124B_DTI'	'DTI'	14.35	'Boy '	'TDC'
    'TD125B_DTI'	'DTI'	11.30	'Boy '	'TDC'
    'TD126B_DTI'	'DTI'	12.14	'Boy '	'TDC'
    'TD128B_DTI'	'DTI'	13.41	'Boy '	'TDC'
    'TD130B_DTI'	'DTI'	10.96	'Boy '	'TDC'
    'TD131B_DTI'	'DTI'	15.85	'Boy '	'TDC'
    'TD132_CCN_DTI'	'DTI'	13	'Girl'	'TDC'
    'TD133B_CCN_DTI'	'DTI'	10.24	'Boy '	'TDC'
    'TD134_CCN_DTI'	'DTI'	12.65	'Girl'	'TDC'
    'TD135_DTI'	'DTI'	13.85	'Boy '	'TDC'
    'TD136_CCN_DTI'	'DTI'	11.74	'Boy '	'TDC'
    'TD137_DTI'	'DTI'	12.01	'Boy '	'TDC'
    'TD138_CCN_DTI'	'DTI'	11.82	'Boy '	'TDC'
    'TD139_CCN_DTI'	'DTI'	9.790	'Boy '	'TDC'
    'TD140_CCN_DTI'	'DTI'	11.92	'Boy '	'TDC'
    'TD142_DTI'	'DTI'	13.82	'Girl'	'TDC'
    'TD143_DTI'	'DTI'	9.500	'Boy '	'TDC'
    'TD144_DTI'	'DTI'	11.82	'Boy '	'TDC'
    'TD145_DTI'	'DTI'	12.73	'Girl'	'TDC'
    'TD24C_DTI'	'DTI'	17.09	'Boy '	'TDC'
    'TD32C_DTI'	'DTI'	17.97	'Boy '	'TDC'
    'TD86C_DTI'	'DTI'	14.88	'Boy '	'TDC'
    'TD97B_DTI'	'DTI'	10.34	'Boy '	'TDC'
    'TD99B_DTI'	'DTI'	13.44	'Boy '	'TDC'};
end
