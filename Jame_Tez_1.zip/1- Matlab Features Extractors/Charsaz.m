ccc
load('H_Klass')
RSF_TDC=cat(3,mA,mC);
RSF_ASD=cat(3,mB,mD);
DTI_TDC=cat(3,mE,mG);
DTI_ASD=cat(3,mF,mH);
save('chargruh.mat','RSF_TDC','RSF_ASD','DTI_TDC','DTI_ASD')