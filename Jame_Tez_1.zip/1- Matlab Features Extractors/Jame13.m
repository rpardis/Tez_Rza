%% Script neme: Jame13.m
ccc
disp('1:CC 2:Lambda 3:cpl 4:Gamma 5:Small_Worldnes 6:Modularity')
disp('7:Betweenness 8:Closeness, 9: Eigen_Centrality')
f0=input('which function? >>> ');
mod=input('Which mode? 0: rs-fMRI 1: DTI >>> ')==1;
if f0==5
    if mod=='0'
        SWN_RSF
    else
        SWN_DTI
    end
    return;
end
if f0==2||f0==4
    disp('---------------------')
    disp('Higher No. of Iterations will need drastic longer execution time')
    NI=input('No. of Iterations >>> ');%# Iterations
else
    NI=1;
end
N_dens=input('No. of density points: 0:normal, 1:test >>> ')==1;
For_SWN=0;
if f0==2||f0==4
    For_SWN=input('Save outputs for Small worldness ? 1:yes  0:no   >>>   ')==1;
end
load('H_Klass')

switch f0
    case 1
        FUNC=str2func('CC_bu');
        F_CCR=str2func('yekk');
        txti='Clustering Cofficients';
        txy='CC';
    case 2
        FUNC=str2func('CC_bu');
        F_CCR=str2func('CCR');
        txti='Normalized Clustering Cofficients (Lambdas)';
        txy='Lambda';
    case 3
        FUNC=str2func('cpl');
        F_CCR=str2func('yekk');
        txti='Characteristic Path Lengths (CPLs)';
        txy='CPL';
    case 4
        FUNC=str2func('cpl');
        F_CCR=str2func('CCR');
        txti='Normalized Characteristic Path Lengths (Gammas)';
        txy='Gamma';
    case 5
        SWN;
        return;
    case 6
        FUNC=str2func('modularity_Q');
        F_CCR=str2func('yekk');
        mA(mA<0)=0;mB(mB<0)=0;mC(mC<0)=0;mD(mD<0)=0;
        mE(mE<0)=0;mF(mF<0)=0;mG(mG<0)=0;mH(mH<0)=0;
        mgM=mean(cat(3,mA,mC,mB,mD),3);
        mgD=mean(cat(3,mE,mG,mF,mH),3);
        mgBM=mean(cat(3,mA,mB),3);
        mgGM=mean(cat(3,mC,mD),3);
        mgBD=mean(cat(3,mE,mF),3);
        mgGD=mean(cat(3,mG,mH),3);
        [CIM,~]=Modulator_U_Fix(mgM);
        [CID,~]=Modulator_U_Fix(mgD);
        [CIBM,~]=Modulator_U_Fix(mgBM);
        [CIGM,~]=Modulator_U_Fix(mgGM);
        [CIBD,~]=Modulator_U_Fix(mgBD);
        [CIGD,~]=Modulator_U_Fix(mgGD);
        txti='Modularities';
        txy='Modularity';
    case 7
        FUNC=str2func('btwn');
        F_CCR=str2func('yekk');
        txti='Betweenness Centrality Scores';
        txy='Betweenness';
    case 8
        FUNC=str2func('clsn');
        F_CCR=str2func('yekk');
        txti='Closeness Centrality Scores';
        txy='Closeness';
    case 9
        FUNC=str2func('eigv');
        F_CCR=str2func('yekk');
        txti='Eigen Vector Centrality var';
        txy='VEVC32';
        load('Eigeners.mat')
%         global shr_b shr_g shr_bg
        CIM=shr_X_M;CIBM=shr_b_M;CIGM=shr_g_M;
        CID=shr_X_D;CIBD=shr_b_D;CIGD=shr_g_D;
%         load('Eigeners2.mat');CIM=shr;
end
if N_dens
    np=2;
else
    if mod
        np=3;
    else
        np=18;
    end
end
if ~mod
    td=cat(3,mA,mC);
    asd=cat(3,mB,mD);
    sps=linspace(0.15,0.32,np);
    mE=mA;mF=mB;mG=mC;mH=mD;
else
    td=cat(3,mE,mG);
    asd=cat(3,mF,mH);
    sps=[.06,.065,0.07];
    if f0==6||f0==9
        CIM=CID;CIBM=CIBD;CIGM=CIGD;
    end
end
[~,~,ntd]=size(td);
[~,~,nasd]=size(asd);

ctm=zeros(np,ntd);
cam=zeros(np,nasd);



p_p_dp=zeros(1,np);

jj=0;
for ss=sps
    jj=jj+1;
    fprintf('%.3f of %.3f done!\n',sps(jj),sps(end))
    %% Both genders
    for ii=1:ntd
        W=td(:,:,ii);
        T0=threshold_p_in(W, ss);
        T=double(T0>0);
        if f0==6||f0==9
            M_TD=FUNC(T,CIM);
        else
            M_TD=mean(FUNC(T));
        end
        ccr_td=F_CCR(T,NI,FUNC);
        ctm(jj,ii)=M_TD/ccr_td;
    end
    for ii=1:nasd
        W=asd(:,:,ii);
        T0=threshold_p_in(W, ss);
        T=double(T0>0);
         if f0==6||f0==9
            M_TD=FUNC(T,CIM);
        else
            M_TD=mean(FUNC(T));
        end
        ccr_td=F_CCR(T,NI,FUNC);
        cam(jj,ii)=M_TD/ccr_td;
    end
    [~,p_p_dp(jj)]=ttest2(ctm(jj,:),cam(jj,:));
    
end
ctm_med=median(ctm,2);
cam_med=median(cam,2);
if ~mod
    figure(2)
    plot(sps,p_p_dp,'ko-','LineWidth', 2,'DisplayName','Both genders')    
    %hold off
    legend('show')
    grid on
    xlabel('Network Density')
    ylabel('P-Values')
    ee=sprintf('P-Values for rsf %s',txy);
    title(ee)
    set(gcf,'position',[0,0,600,400])
    dd=sprintf('Grafz/rsf_%s.png',txy);
    saveas(gcf,dd)
    %% Saving outputs
    y_ASD=mean(cam,1);
    y_TDC=mean(ctm,1);
    %%%%%%%%%%%%

    if ~N_dens
        txsave=sprintf('Nine_Metrics/%s_rsf_BG2',txy);
        save(txsave,'y_ASD','y_TDC','y_A','y_B','y_C','y_D')
    end
    if For_SWN
        M_ASD=cam;
        M_TDC=ctm;
        M_A=cEm;
        M_B=cFm;
        M_C=cGm;
        M_D=cHm;
        txswn=sprintf('Nine_Metrics/%s_swn_rsf_BG2',txy);
        save(txswn,'M_ASD','M_TDC','M_A','M_B','M_C','M_D')
    end
else
    figure(3)
    hold on
    plot(sps,p_p_dp,'ko-','LineWidth', 2,'DisplayName','Both genders')
    
    hold off
    legend('show')
    grid on
    xlabel('Network Density')
    ylabel('P-Values')
    ee=sprintf('P-Values for %s',txy);
    title(ee)
    dd=sprintf('Grafz/DTII_%s.png',txy);
    saveas(gcf,dd)
    %% Saving outputs
    y_AS=mean(cam,1);
    y_TD=mean(ctm,1);
    if ~N_dens
        txsave=sprintf('Nine_Metrics/%s_DTII_BG2',txy);
        save(txsave,'y_AS','y_TD')
    end
    if For_SWN
        M_AS=cam;
        M_TD=ctm;
        M_E=cEm;
        M_F=cFm;
        M_G=cGm;
        M_H=cHm;
        txswn=sprintf('Nine_Metrics/%s_swn_DTII_BG2',txy);
        save(txswn,'M_AS','M_TD','M_E','M_F','M_G','M_H')
    end
end

%%Functions
function W = threshold_p_in(W, p)
n=size(W,1); %number of nodes
W(1:n+1:end)=0; %clear diagonal

if max(max(abs(W-W.'))) < 1e-10 %if symmetric matrix
    W=triu(W); %ensure symmetry is preserved
    ud=2; %halve number of removed links
else
    ud=1;
end

ind=find(W); %find all links
E=sortrows([ind W(ind)], -2); %sort by magnitude
en=round((n^2-n)*p/ud); %number of links to be preserved

W(E(en+1:end,1))=0; %apply threshold

if ud==2 %if symmetric matrix
    W=W+W.'; %reconstruct symmetry
end
end

%%
function uu=cpl(D)
[~,didd] = reachdist(D);
didd(isinf(didd))=0;
uu=mean(didd(:));
end
function cc17m=CCR(aa1,NI,FUNC)
cc17=0.0;
for tt=1:NI
    [R,~]=randmio_u(aa1);
    cctt=mean(FUNC(R));
    cc17=cctt+cc17;
end
cc17m=cc17/tt;
end
%% randmio
function [R,eff]=randmio_u(R)
n=size(R,1);
[i,j]=find(tril(R));
K=length(i);
ITER=K;
% maximal number of rewiring attempts per 'iter'
maxAttempts= round(n*K/(n*(n-1)));
% actual number of successful rewirings
eff = 0;
for iter=1:ITER
    att=0;
    while (att<=maxAttempts) %while not rewired
        while 1
            e1=ceil(K*rand);
            e2=ceil(K*rand);
            while (e2==e1)
                e2=ceil(K*rand);
            end
            a=i(e1); b=j(e1);
            c=i(e2); d=j(e2);
            if all(a~=[c d]) && all(b~=[c d])
                break %all four vertices must be different
            end
        end
        if rand>0.5
            i(e2)=d; j(e2)=c; %flip edge c-d with 50% probability
            c=i(e2); d=j(e2); %to explore all potential rewirings
        end
        %rewiring condition
        if ~(R(a,d) || R(c,b))
            R(a,d)=R(a,b); R(a,b)=0;
            R(d,a)=R(b,a); R(b,a)=0;
            R(c,b)=R(c,d); R(c,d)=0;
            R(b,c)=R(d,c); R(d,c)=0;
            j(e1) = d; %reassign edge indices
            j(e2) = b;
            eff = eff+1;
            break;
        end %rewiring condition
        att=att+1;
    end %while not rewired
end %iterations
end

function C=CC_bu(G)
n=length(G);
C=zeros(n,1);

for u=1:n
    V=find(G(u,:));
    k=length(V);
    if k>=2 %degree must be at least 2
        S=G(V,V);
        C(u)=sum(S(:))/(k^2-k);
    end
end
end
function  [R,D] = reachdist(CIJ)

% initialize
R = CIJ;
D = CIJ;
powr = 2;
N = size(CIJ,1);
CIJpwr = CIJ;

% Check for vertices that have no incoming or outgoing connections.
% These are "ignored" by 'reachdist'.
id = sum(CIJ,1);       % indegree = column sum of CIJ
od = sum(CIJ,2)';      % outdegree = row sum of CIJ
id_0 = find(id==0);    % nothing goes in, so column(R) will be 0
od_0 = find(od==0);    % nothing comes out, so row(R) will be 0
% Use these columns and rows to check for reachability:
col = setxor(1:N,id_0);
row = setxor(1:N,od_0);

[R,D,powr] = reachdist2(CIJ,CIJpwr,R,D,N,powr,col,row);

% "invert" CIJdist to get distances
D = powr - D+1;

% Put 'Inf' if no path found
D(D==(N+2)) = Inf;
D(:,id_0) = Inf;
D(od_0,:) = Inf;
end


%----------------------------------------------------------------------------

function  [R,D,powr] = reachdist2(CIJ,CIJpwr,R,D,N,powr,col,row)

% Olaf Sporns, Indiana University, 2002/2008

CIJpwr = CIJpwr*CIJ;
R = double(R | ((CIJpwr)~=0));
D = D+R;

if ((powr<=N)&&(~isempty(nonzeros(R(row,col)==0)))) 
   powr = powr+1;
   [R,D,powr] = reachdist2(CIJ,CIJpwr,R,D,N,powr,col,row); 
end;
end

function y=yekk(varargin)
y=1;
end

function bb=btwn(B)
A=(B+B')./2;
A(A<.5)=0;
A(A>.5)=1;
G = graph(A);
wbc = centrality(G,'betweenness','Cost',G.Edges.Weight);
bb=wbc';
end
function bb=clsn(B)
A=(B+B')./2;
A(A<.5)=0;
A(A>.5)=1;
G = graph(A);
wbc = centrality(G,'closeness');
bb=wbc';
end
function bb=eigv(B,shr)
A=(B+B')./2;
A(A<.5)=0;
A(A>.5)=1;
G = graph(A);
wbc = centrality(G,'eigenvector');
% bb=wbc(shr(1:8));
% d0=sort(wbc,'descend');
mm=16;
d00=cat(2,shr(1:mm),shr(256-mm+1:256));
w0=wbc(d00);
% nd10=ceil(length(d0)/20);
bb=mean(var(w0));
end
function SWN_RSF
disp('2 Gamma and 2 Lambda matrices must be ready ')

%% RSF
Gamma=load('Nine_Metrics\Gamma_swn_rsf_BG2.mat');
Lambda=load('Nine_Metrics\Lambda_swn_rsf_BG2.mat');
txti='Small Worlnesses';
txy='SW';
cam=Lambda.M_ASD./Gamma.M_ASD;
ctm=Lambda.M_TDC./Gamma.M_TDC;
cAm=Lambda.M_A./Gamma.M_A;
cBm=Lambda.M_B./Gamma.M_B;
cCm=Lambda.M_C./Gamma.M_C;
cDm=Lambda.M_D./Gamma.M_D;
[ep,~]=size(cam);


p_p_dp=zeros(1,ep);
p_p_p=zeros(1,ep);
p_p_d=zeros(1,ep);
for jj=1:ep
    [~,p_p_dp(jj)]=ttest2(ctm(jj,:),cam(jj,:));
    [~,p_p_p(jj)]=ttest2(cAm(jj,:),cBm(jj,:));
    [~,p_p_d(jj)]=ttest2(cCm(jj,:),cDm(jj,:));
end
figure(3)
sps=linspace(0.15,0.32,ep);
% hold on
plot(sps,p_p_dp,'ko-','LineWidth', 2,'DisplayName','Both genders')
% plot(sps,p_p_p,'bp--','DisplayName','Boys')
% plot(sps,p_p_d,'md-.','DisplayName','Girls')
% 
% hold off
legend('show')
grid on
xlabel('Network Density')
ylabel('P-Values')
ee=sprintf('P-Values for %s',txti);
title(ee)
dd=sprintf('Grafz/rsf_%s.png',txy);
saveas(gcf,dd)
%%% savings
y_ASD=mean(cam,1);
y_TDC=mean(ctm,1);
y_A=mean(cAm,1);
y_B=mean(cBm,1);
y_C=mean(cCm,1);
y_D=mean(cDm,1);
txsave=sprintf('Nine_Metrics/%s_rsf_BG2',txy);
save(txsave,'y_A','y_B','y_C','y_D','y_ASD','y_TDC')
end
function SWN_DTI
%% Script neme: SWN.m
disp('2 Gamma and 2 Lambda matrices must be ready ')
%% DTI
Gamma=load('Nine_Metrics\Gamma_swn_DTI_BG2.mat');
Lambda=load('Nine_Metrics\Lambda_swn_DTI_BG2.mat');
txti='Small Worlnesses';
txy='SW';
cam=Lambda.M_AS./Gamma.M_AS;
ctm=Lambda.M_TD./Gamma.M_TD;
cEm=Lambda.M_E./Gamma.M_E;
cFm=Lambda.M_F./Gamma.M_F;
cGm=Lambda.M_G./Gamma.M_G;
cHm=Lambda.M_H./Gamma.M_H;
[ep,~]=size(cam);

sps=linspace(0.15,0.32,ep);
p_p_dp=zeros(1,ep);
p_p_p=zeros(1,ep);
p_p_d=zeros(1,ep);
for jj=1:ep
    [~,p_p_dp(jj)]=ttest2(ctm(jj,:),cam(jj,:));
    [~,p_p_p(jj)]=ttest2(cEm(jj,:),cFm(jj,:));
    [~,p_p_d(jj)]=ttest2(cGm(jj,:),cHm(jj,:));
end
figure(3)
plot(sps,p_p_dp,'ko-','LineWidth', 2,'DisplayName','Both genders')
legend('show')
grid on
xlabel('Network Density')
ylabel('P-Values')
ee=sprintf('P-Values for %s',txti);
title(ee)
dd=sprintf('Grafz/DTI_%s.png',txy);
saveas(gcf,dd)
%%% savings
y_AS=mean(cam,1);
y_TD=mean(ctm,1);
y_E=mean(cEm,1);
y_F=mean(cFm,1);
y_G=mean(cGm,1);
y_H=mean(cHm,1);
txsave=sprintf('Nine_Metrics/%s_DTI_BG2',txy);
save(txsave,'y_E','y_F','y_G','y_H','y_AS','y_TD')
end