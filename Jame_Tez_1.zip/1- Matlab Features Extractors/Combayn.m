% Script neme: Combayn.m
% Reza Pardis
% 2023.02.05
ccc
%% Enving UCLA Dataset
diir=sprintf('Noh_Vijgy');
ucd=dir(diir);
addpath(diir);
lu=size(ucd,1);
Lyst=cell(lu,1);
for ii=1:lu
    Lyst{ii}=ucd(ii).name;
end
%% DTI
inc={'DTI'};
exc={'swn'};
fiD_DTI=cell(lu,1);
jj=0;
for ii=1:lu
    ff=~isempty(strfind(Lyst{ii},inc{1}))*isempty(strfind(Lyst{ii},exc{1}));
    if ff==1
        jj=jj+1;
        fiD_DTI{jj}=Lyst{ii};
    end
end
for ll=lu:-1:1
    % disp(ll)
    if isempty(fiD_DTI{ll})
        fiD_DTI(ll)=[];
    end
end
%% DTI ezafe shwd
[L_DTI,~]=size(fiD_DTI);
if L_DTI~=9
    error('%i features are missing!  ',9-L_DTI);
end
deer=sprintf('%s/%s',diir,fiD_DTI{1});
mat_DTI0=load(deer);
[~,s_AS]=size(mat_DTI0.y_AS);D_X_T=zeros(s_AS,L_DTI);
[~,s_TD]=size(mat_DTI0.y_TD);D_X_A=zeros(s_TD,L_DTI);
for ii=1:L_DTI
    deer=sprintf('%s/%s',diir,fiD_DTI{ii});
    mat_DTI=load(deer);
    D_X_T(:,ii)=mat_DTI.y_AS;
    D_X_A(:,ii)=mat_DTI.y_TD;
end
[ro,so]=size(D_X_A);
DA=zeros(ro,so+1);
DA(:,1)=0;
for pp=1:so
    DA(:,pp+1)=D_X_A(:,pp);
end
[ro,so]=size(D_X_T);
DT=zeros(ro,so+1);
DT(:,1)=1;
for pp=1:so
    DT(:,pp+1)=D_X_T(:,pp);
end
DTI=cat(1,DA,DT);


%% rsf
inc={'rsf'};
exc={'swn'};
fiD_rsf=cell(lu,1);
jj=0;
for ii=1:lu
    ff=~isempty(strfind(Lyst{ii},inc{1}))*isempty(strfind(Lyst{ii},exc{1}));
    if ff==1
        jj=jj+1;
        fiD_rsf{jj}=Lyst{ii};
    end
end
for ll=lu:-1:1
    % disp(ll)
    if isempty(fiD_rsf{ll})
        fiD_rsf(ll)=[];
    end
end
%% rsf ezafe shwd
[L_rsf,~]=size(fiD_rsf);
if L_rsf~=9
    error('%i features are missing!  ',9-L_rsf);
end
deer=sprintf('%s/%s',diir,fiD_rsf{1});
mat_rsf0=load(deer);

[~,s_ASD]=size(mat_rsf0.y_ASD);RSF_X_T=zeros(s_ASD,L_rsf);
[~,s_TDC]=size(mat_rsf0.y_TDC);RSF_X_A=zeros(s_TDC,L_rsf);
for ii=1:L_rsf
    deer=sprintf('%s/%s',diir,fiD_rsf{ii});
    mat_rsf=load(deer);
    RSF_X_T(:,ii)=mat_rsf.y_ASD;
    RSF_X_A(:,ii)=mat_rsf.y_TDC;
end
[ro,so]=size(RSF_X_A);
RSFA=zeros(ro,so+1);
RSFA(:,1)=0;
for pp=1:so
    RSFA(:,pp+1)=RSF_X_A(:,pp);
end
[ro,so]=size(RSF_X_T);
RSFT=zeros(ro,so+1);
RSFT(:,1)=1;
for pp=1:so
    RSFT(:,pp+1)=RSF_X_T(:,pp);
end
RSF=cat(1,RSFA,RSFT);
%%
headerz={'is_ASD','CC','Lambda','CPL','Gamma','Small_Worldnes','Modularity','Betweenness','Closeness','Eigen_Centrality'};
Sellul_D=arr2cell(headerz,DTI);
Sellul_R=arr2cell(headerz,RSF);
xlswrite('Komb.xls',Sellul_D,'DTI')
xlswrite('Komb.xls',Sellul_R,'RSF')
% H=[10,4,3,2];
function Sellul=arr2cell(Header,Arayh)
[r,s]=size(Arayh);
gg=length(Header);
if gg~=s
    error('Header mismatches array')
end
Sellul=cell(r+1,s);
for jj=1:s
    Sellul{1,jj}=Header{jj};
end
for ii=1:r
    for jj=1:s
        Sellul{ii+1,jj}=Arayh(ii,jj);
    end
end
end