%% Script neme: ccc.m
clc, clear all, close all, 