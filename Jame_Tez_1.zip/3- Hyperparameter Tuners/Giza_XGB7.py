# script name: Giza_XGB7.py
import random as rd
import matplotlib.pyplot as plt
import copy
import numpy as np
from sklearn.model_selection import cross_val_score,RepeatedStratifiedKFold
from xgboost import XGBClassifier
import pandas as pd
import time
from datetime import datetime
import winsound



#%% Initialization

isdti=int(input(' Use DTIs?  >>>  '))


NR=int(input('CV n_repeats (df=17) >>>  '))
nPop=int(input('#Workers (df=40) >>>  '))# Number of workers
T00=time.time()
#%%
nVar=12;                     # Number of Decision Variables

# Giza Pyramids Construction (GPC) Parameters
MaxIteration=60;   # Maximum Number of Iterations (Days of work)        
G = 9.8;             # Gravity
Tetha = 16;          # Angle of Ramp
MuMin = 1;           # Minimum Friction 
MuMax = 11;          # Maximum Friction
pSS= 0.98;              # Substitution Probability

#%%
ee=1e-6
Hdud = np.array([[ee, 1-ee], [0, 1.5],[ee, 1-ee],[ee, 1-ee],[ee, 1-ee],\
            [0.4, 0.8],[1, 40],[0, 2],[10, 220],\
             [ee, 1-ee],[ee, 1-ee],[ee, 1-ee]])
VarMin= list(Hdud[:,0]);                 # Decision Variables Lower Bound
VarMax= list(Hdud[:,1]);                  # Decision Variables Upper Bound   
# Convert lb and ub to list if it is only num
if not isinstance(VarMin, list):
  VarMin = [VarMin] * nVar
if not isinstance(VarMax, list):
  VarMax = [VarMax] * nVar

# bounds = [[ee, 1-ee], [0, 6.0]]


#%% Functionz 
#def Initialize the position by dimension
def initial(nVar,VarMax,VarMin):
    sol=np.zeros((1,nVar))
    for i in range(nVar):
       sol[:,i]=np.random.rand() * (VarMax[i] - VarMin[i]) + VarMin[i]
    return sol
def zman(tn,t0):
    print('__________________________________')
    T03=tn-t0
    H03=int(T03/3600)
    M03=int((T03-H03*3600)/60)
    S03=int(T03-H03*3600-M03*60)
    print('Elapsed %i H %i M %i s'%(H03,M03,S03))
    print(datetime.now().strftime("%D & %H:%M:%S"))
def saat(T03):
    H03=int(T03/3600)
    M03=int((T03-H03*3600)/60)
    S03=int(T03-H03*3600-M03*60)
    return ('%i H %i M %i s'%(H03,M03,S03))
#%%
TT=(nPop)*NR*0.3
print('\n\nEach iteration takes almost %s. Agree?' %saat(TT))
int(input('a numer: go on    a charactr: no   >>>   '))
#%% Setting up the dataset

# rz_iter_RS=int(inpTt(' #Excavation points for Giza  >>>  ')) # 100 iters = 1 minute
# NoRS=int(input(' #Random states?  >>>  '))
if isdti==1:
    hh_X=pd.read_excel(open('Mjazat_STD.xls', 'rb'), sheet_name='X_D', header=0)
    pp0=np.array([0.511892,0.694051,0.635246,0.999999,0.699154,0.548915,29.7729,1.123,90.0135,0.936308,0.9547,0.996168])
else:
    hh_X=pd.read_excel(open('Mjazat_STD.xls', 'rb'), sheet_name='X_R', header=0)
    pp0=np.array([0.516883,0.888528,0.154944,0.472647,0.256285,0.508916,17.593,0.875278,119.77,0.566911,0.424603,0.822507])
data1_X=pd.DataFrame.to_numpy(hh_X)
data_X=np.array(data1_X)
[r_X,s_X]=np.shape(data_X)
X0_X = data_X[:,0:s_X-1]
X=X0_X.astype('float')
Y0_X = data_X[:,s_X-1]
y=Y0_X.astype('int')
#%% Giza
Danh=1402#np.random.randint(1e6)
Giza_Model=XGBClassifier(use_label_encoder=False,\
            eval_metric='logloss',objective ='binary:logistic')
cv0 = RepeatedStratifiedKFold(n_splits=10, n_repeats=NR, random_state=Danh)
# genetic algorithm search for continuous function optimization

# from mpl_toolkits.mplot3d import Axes3D
# objective function
def DqT(x):
    # print('\t\tx[0]=%.4f'%x[0])
    Giza_Model.learning_rate = x[0]
    Giza_Model.scale_pos_weight = x[1]
    Giza_Model.colsample_bylevel = x[2]
    Giza_Model.colsample_bytree = x[3]
    Giza_Model.gamma = x[4]
    Giza_Model.max_delta_step = x[5]
    Giza_Model.max_depth =int( x[6])
    Giza_Model.min_child_weight = x[7]
    Giza_Model.n_estimators = int(x[8])
    Giza_Model.reg_alpha = x[9]
    Giza_Model.reg_lambda = x[10]
    Giza_Model.subsample = x[11]

    baseline = cross_val_score(Giza_Model, X, y, cv=cv0,scoring='accuracy').mean()
    return baseline


# Initialize Best Solution Ever Found
best_workerPosition=np.zeros((1, nVar))
best_workerCost=-np.inf;


# Initialize the Positions and Accus
Positions = np.zeros((nPop, nVar))
Accus = np.full(nPop, -np.inf)

for i in range(nPop):
  Positions[i,:] = initial(nVar,VarMax,VarMin)
  if i==0:
      Positions[i,:]=pp0
  Accus[i] = DqT(Positions[i,:])
  # print(Accus[i])  
  if (Accus[i] >= best_workerCost):
      best_workerPosition=Positions[i,:]
      best_workerCost=Accus[i];
Accus0 = copy.deepcopy(Accus)
# Array to Hold Best Cost Values
BestCost=np.zeros(MaxIteration+1)
BestCost[0]=best_workerCost
zman(time.time(),T00)
print('At iteration 0 accuracy is %f'%(best_workerCost));
#%% Giza Pyramids Construction (GPC) Algorithm Main Loop
for it in range(MaxIteration):
    T01=time.time()
    newpopPosition=np.zeros((nPop, nVar))
    newpopCost=np.full(nPop, -np.inf)
    
    for i in range(nPop):
        newpopCost[i]=-np.inf 
       
        V0= rd.random()                                                                                      # Initial Velocity                                      
        Mu= MuMin+(MuMax-MuMin)*rd.random()                                                                  # Friction
        d = (V0**2)/((2*G)*(np.sin(np.radians(Tetha))+(Mu*np.cos(np.radians(Tetha)))))                       # Stone Destination
        x = (V0**2)/((2*G)*(np.sin(np.radians(Tetha))))   
        epsilon=initial(nVar,(np.array(VarMax)-np.array(VarMin))/2,-((np.array(VarMax)-np.array(VarMin))/2)) # Worker Movement
        newsolPosition = (Positions[i,:]+d)+x*epsilon                 # Position of Stone and Worker
      # newsol.Position = (pop(i).Position+d)+(x*epsilon);                  # Note: In some cases or some problems use this instead of the previous line to get better results
        newsolPosition=np.maximum(newsolPosition,VarMin)
        newsolPosition=np.minimum(newsolPosition,VarMax)
       
        # Substitution
        z=np.zeros(nVar)
        k0 = rd.randint(0,nPop)
        for k in range(nVar):
            if (k==k0 or rd.random()<=pSS):
                z[k]=newsolPosition[0,k]
            else:
                z[k]=Positions[i,k]
       
        newsolPosition=z;
        
        newsolCost=DqT(newsolPosition)
        # print(z)
        # print('NSC = %f'%newsolCost)
        # print('pos=%f,cost=%f'%(z,newsolCost))
        #print('newsolCost',i,': ',newsolCost)
        if (newsolCost >= newpopCost[i]):
                newpopPosition[i,:]=newsolPosition
                newpopCost[i]=newsolCost
                if (newpopCost[i] >= best_workerCost):
                    best_workerPosition = newpopPosition[i,:]
                    best_workerCost = newpopCost[i]
                    
        # Merge
    Positions = np.concatenate((Positions, newpopPosition))        
    Accus = np.concatenate((Accus, newpopCost)) 
        # Sort
    newpopCost1 = copy.deepcopy(newpopCost)     
    sortedIndices4 = np.argsort(-Accus)    
    sortedIndices = np.argsort(-Accus)
    Positions = Positions[sortedIndices]
    Accus = Accus[sortedIndices]        
    
    # Truncate Extra Harmonies
    Positions=Positions[0:nPop,:]
    Accus=Accus[0:nPop]
    
    # Update Best Solution Ever Found
    BestSolPos = Positions[0,:]
    BestSolCost = Accus[0]
    BestCost[it+1]=BestSolCost
    qq=BestSolCost
    #%% Show Iteration Information
    zman(time.time(),T01)
    print('At iteration %i accuracy is %0.3f'%(it+1,BestCost[it+1]))
    if isdti==1:
        rek=0.67
    else:
        rek=0.60
    if qq>rek:
        print('***New Record***')
        print('=> Giza Results at It %i:'%it)
        # print('\tWith gamma= %.5f, LR= %.5f,SPW= %.5f :'%(Xh['gamma'],Xh['learning_rate'],Xh['scale_pos_weight']))
        print('\tGiza  Accuracy =  %.5f' %qq)
        fayl = open('Giza_rekordz7_.txt','a')
        fayl.write('\n__________________________\n')        
        fayl.write('\nn_repeats = %s\n'%str(NR))
        fayl.write('\nisdti = %s\n'%str(isdti))
        fayl.write('\nRandom State = %s\n'%str(Danh))
        fayl.write('\n\tAccuracy = %s\n\n'%str(qq))
        fayl.write(str(BestSolPos))
        fayl.close()
    else:
        print('???No record. Accuracy was %0.2f'%(qq*100))
    winsound.Beep(7000, 100)
    time.sleep(13)
print(BestSolPos)
plt.plot(BestCost,'m*-')
plt.xlabel('#Iteration') 
plt.ylabel('Accuracy') 
plt.title('Giza PC tunes XGB parameters on DTI') 
plt.grid()
if isdti==1:
    plt.title('Giza PC tunes XGB parameters on DTI')
    plt.savefig('Giza_DTI3.png',dpi=250)
else:
    plt.title('Giza PC tunes XGB parameters on rs-fMRI')
    plt.savefig('Giza_RSF3.png',dpi=250)  
winsound.Beep(700, 3000)