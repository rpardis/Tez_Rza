# Program Name: RS_XGB5.py
from sklearn.model_selection import cross_val_score,\
    RepeatedStratifiedKFold,\
    RandomizedSearchCV
from xgboost import XGBClassifier
from scipy.stats import uniform
import pandas as pd
import numpy as np
# from sklearn.metrics import accuracy_score,f1_score,recall_score,precision_score
import time
from datetime import datetime
#%% Inputting
isdti=int(input(' Use DTIs?  >>>  '))
N_D=int(input('Features dimension  >>>  '))
NR=int(input('CV n_repeats  (Accuracy of outputs)>>>  '))
print('\n\nEvery intra-RS Epoch almost %i seconds'%(NR*1))
rz_iter_RS=int(input('Ditches for RS  >>>  ')) # 100 iters = 1 minute
#%% Importing the excel database
T00=time.time()
if isdti==1:
    hh_X=pd.read_excel(open('Mjazat_STD.xls', 'rb'), sheet_name='X_D', header=0)
else:
    hh_X=pd.read_excel(open('Mjazat_STD.xls', 'rb'), sheet_name='X_R', header=0)
data1_X=pd.DataFrame.to_numpy(hh_X)
data_X=np.array(data1_X)
[r_X,s_X]=np.shape(data_X)
X0_X = data_X[:,0:s_X-1]
X=X0_X.astype('float')
Y0_X = data_X[:,s_X-1]
y=Y0_X.astype('int')
[hx,dx]=np.shape(X)
X=np.delete(X, range(N_D,dx), 1)
#%% Random Search
RS_Model=XGBClassifier(eval_metric='logloss',objective ='binary:logistic')
ee=1e-6
RS_params = {"colsample_bylevel": uniform(ee,1-ee), # Best value yet:.73
             "colsample_bytree": uniform(ee ,1-ee ), # Best value yet:.15
             "gamma": uniform(ee , 1-ee), # Best value yet:0.0066
             "learning_rate": uniform(ee ,1-ee ), # Best value yet:0.73
             "max_delta_step": uniform(0 , 4), # Best value yet:0.32
             "max_depth": range( 1,88 ), # Best value yet:8
             "min_child_weight": uniform(0 , 4), # Best value yet:1.83
             "n_estimators": range (1 ,123 ), # Best value yet:78
             "reg_alpha": uniform(ee , 4), # Best value yet:0.79
             "reg_lambda": uniform(ee , 4), # Best value yet:1.99
             "subsample": uniform(ee ,1-ee ), # Best value yet:.086
             "scale_pos_weight": uniform(0 ,22 ), # Best value yet:0.20721
             }
Accz=np.zeros([100])
for ITS in range(100):
    Danh=np.random.randint(1e6)
    cv0 = RepeatedStratifiedKFold(n_splits=10, n_repeats=NR, random_state=Danh)

    rs = RandomizedSearchCV(RS_Model, \
                            param_distributions=RS_params, 
                            scoring='accuracy', cv=cv0,n_iter=rz_iter_RS)
    
    # Run random search for 25 iterations
    T01=time.time()
    rs.fit(X, y);
    y_rs = np.maximum.accumulate(rs.cv_results_['mean_test_score'])
    
    yo=rs.cv_results_['mean_test_score']
    qq=np.max(yo)
    iqq=np.argwhere(yo==qq)
    Xh=rs.cv_results_['params'][iqq[0,0]]
    RS_Model.colsample_bylevel=Xh['colsample_bylevel']
    RS_Model.colsample_bytree=Xh['colsample_bytree']
    RS_Model.gamma=Xh['gamma']
    RS_Model.learning_rate=Xh['learning_rate']
    RS_Model.max_delta_step=Xh['max_delta_step']
    RS_Model.max_depth=Xh['max_depth']
    RS_Model.min_child_weight=Xh['min_child_weight']
    RS_Model.n_estimators=Xh['n_estimators']
    RS_Model.reg_alpha=Xh['reg_alpha']
    RS_Model.reg_lambda=Xh['reg_lambda']
    RS_Model.subsample=Xh['subsample']
    RS_Model.scale_pos_weight=Xh['scale_pos_weight']
    
    HH = cross_val_score(RS_Model, X, y, cv=cv0,scoring='accuracy').mean()
    print('__________________________________')
    T03=time.time()-T01
    H03=int(T03/3600)
    M03=int((T03-H03*3600)/60)
    S03=int(T03-H03*3600-M03*60)
    print('Elapsed %i H %i M %i s'%(H03,M03,S03))
    print(datetime.now().strftime("%D & %H:%M:%S"))
    
    Accz[ITS]=qq
    if qq>0.6:
        print('***New Record***')
        print('=> Random search Results at It %i:'%ITS)
        # print('\tWith gamma= %.5f, LR= %.5f,SPW= %.5f :'%(Xh['gamma'],Xh['learning_rate'],Xh['scale_pos_weight']))
        print('\tRandom search  Accuracy =  %.5f' %qq)
        fayl = open('ReRS_STD.txt','a')
        fayl.write('\n__________________________\n')        
        fayl.write('\nn_repeats = %s\n'%str(NR))
        fayl.write('\nisdti = %s\n'%str(isdti))
        fayl.write('\nRandom State = %s\n'%str(Danh))
        fayl.write('\n\tAccuracy = %s\n\n'%str(qq))
        fayl.write(str(Xh))
        fayl.close()
    else:
        print('!No record. Accuracy was %0.2f'%(qq*100))

    