# Script Name: ACO_XGB7.py
import numpy as np
import numpy.matlib
import matplotlib.pyplot as plt
from sklearn.model_selection import cross_val_score,RepeatedStratifiedKFold

from xgboost import XGBClassifier
import pandas as pd
# from pandas.io.excel import ExcelWriter
#from sklearn.metrics import accuracy_score,f1_score,recall_score,precision_score
import time
from datetime import datetime
import winsound
#%%
def zman(tn,t0):
    # print('=======================')
    T03=tn-t0
    H03=int(T03/3600)
    M03=int((T03-H03*3600)/60)
    S03=int(T03-H03*3600-M03*60)
    print('\n\tElapsed %i H %i M %i s'%(H03,M03,S03))
    print(datetime.now().strftime("\t%D & %H:%M:%S"))
def saat(T03):
    H03=int(T03/3600)
    M03=int((T03-H03*3600)/60)
    S03=int(T03-H03*3600-M03*60)
    return ('%i H %i M %i s'%(H03,M03,S03))
T00=time.time()

#%% Importing the excel database
# Vijgz=['Betweenness','CC','CPL','Closeness','Gamma','Lambda','Modularity','SW','EigenValue']


isdti=int(input(' Use DTIs?  >>>  '))#1
NR=int(input('CV n_repeats (df=13) >>>  '))

nPop = int(input('#Primer ants? (df=60) >>>  '))#2            # Population Size (Archive Size)
nSample = int(input('#Extra ants? (df=120)  >>>  '))#4         # Sample Size

MaxIt =int(input('#Iterations?  >>> (df=101) '))# 3          # Maximum Number of Iterations
#%%
TT=(nSample+nPop)*NR*1.6
print('Each iteration takes almost %s s. Agree?' %saat(TT))
int(input('a numer: go on    a charactr: no   >>>   '))
#%%
# rz_iter_RS=int(inpTt(' #Excavation points for Random Search  >>>  ')) # 100 iters = 1 minute
# NoRS=int(input(' #Random states?  >>>  '))

if isdti==1:
    hh_X=pd.read_excel(open('Mjazat_STD.xls', 'rb'), sheet_name='X_D', header=0)
else:
    hh_X=pd.read_excel(open('Mjazat_STD.xls', 'rb'), sheet_name='X_R', header=0)
data1_X=pd.DataFrame.to_numpy(hh_X)
#%% Both
print('_____________________')
data_X=np.array(data1_X)
[r_X,s_X]=np.shape(data_X)
X0_X = data_X[:,0:s_X-1]
X=X0_X.astype('float')
Y0_X = data_X[:,s_X-1]
y=Y0_X.astype('int')
qq0=0

#%% ACO
ACO_Model=XGBClassifier(use_label_encoder=False,\
            eval_metric='logloss',objective ='binary:logistic')
cv0 = RepeatedStratifiedKFold(n_splits=10, n_repeats=NR, random_state=33)
# genetic algorithm search for continuous function optimization

# from mpl_toolkits.mplot3d import Axes3D
# objective function
def Hzinh(x):
    global X,y,cv0
    # print('\t\tx[0]=%.4f'%x[0])
    # print('x[0]=%f,\tx[1]=%f'%(x[0],x[1]))
    ACO_Model.learning_rate = x[0]
    ACO_Model.scale_pos_weight = x[1]
    ACO_Model.colsample_bylevel = x[2]
    ACO_Model.colsample_bytree = x[3]
    ACO_Model.gamma = x[4]
    ACO_Model.max_delta_step = x[5]
    ACO_Model.max_depth =int( x[6])
    ACO_Model.min_child_weight = x[7]
    ACO_Model.n_estimators = int(x[8])
    ACO_Model.reg_alpha = x[9]
    ACO_Model.reg_lambda = x[10]
    ACO_Model.subsample = x[11]

    baseline = cross_val_score(ACO_Model, X, y, cv=cv0,scoring='accuracy').mean()
    # print('Ant accuracy = %.5f'%baseline)
    return baseline
#%%
ee=1e-6
nVar = 12            # Number of Decision Variables
VarSize = [1, nVar]   # Variables Matrix Size
# VarMin = ee         # Decision Variables Lower Bound
# VarMax = 1-ee         # Decision Variables Upper Bound
## ACOR Parameters

q = 0.5              # Intensification Factor (Selection Pressure)
zeta = 1             # Deviation-Distance Ratio
Hdod=np.array([[ee, 1-ee],\
[0, 6.0],[ee, 1-ee],[ee, 1-ee],[ee, 1-ee],\
[0, 2],[1, 40],[0, 2],[10, 220],\
[ee, 1-ee],[ee, 1-ee],[ee, 1-ee]])
#%% Functions
def rdiffH(A,H):
# In tabe, matris A ra bar hasbe sorted_H morattab mikonad
    [d10,d2]=np.shape(A)
    A_sorted=np.zeros(np.shape(A))
    ag=np.argsort(-H,axis=0)
    for ii in range(d10):
        for jj in range(d2):
            A_sorted[ii,jj]=A[ag[ii],jj]
    return A_sorted
def Qmar(P):
#Psedu- randi
    r = np.random.rand(1)[0]
    C = np.cumsum(P)
    j = np.where(r <= C)[0][0]
    return j
def limitor(A,H):
    [d10,d3]=np.shape(A)
    A_limited=np.zeros(np.shape(A))
    for ii in range(d10):
        for jj in range(d3):
            if A[ii,jj]<H[jj,0]:
                A_limited[ii,jj]=H[jj,0]
            elif A[ii,jj]>H[jj,1]:
                A_limited[ii,jj]=H[jj,1]
            else:
                A_limited[ii,jj]=A[ii,jj]
    return A_limited
#%% Initialization ACO
# Create Population Matrix

poz=np.zeros([nPop,nVar])
zed=np.zeros(nPop)
# Initialize Population Members
T01=time.time()
for ii in range(nPop):
    # Create Random Solution
    pozo = np.squeeze(np.random.uniform(ee, 1-ee, VarSize)*\
    np.array([1,6,1,1,1,2,40,2,220,1,1,1]))
    # pozo[6]=int(pozo[6])
    # pozo[8]=int(pozo[8])
    poz[ii,:]=pozo
      # Evaluation
    # print('hhhhhhhhhhhh%i'%ii)
    zed[ii] = Hzinh(pozo)
# Sort Population
# [~, SortOrder] = sort([pop.Cost])
# pop = pop(SortOrder)
pop=rdiffH(poz,zed)
# # Update Best Solution Ever Found
Bestpoz = pop[0]
BestCost0 = Hzinh(pop[0])

zman(time.time(),T00)
print('Iteration #%i : best ant"s accuracy = %f' %(0,BestCost0))
# Array to Hold Best Cost Values
BestCost = np.zeros([MaxIt, 1])
BestCost0 = Hzinh(pozo)
# Solution Weights
a11=np.linspace(1,11,11)
w = 1/(np.sqrt(2*np.pi)*q*nPop)*np.exp(-0.5*((a11-1)/(q*nPop))**2)
# Selection Probabilities
pw = w/np.sum(w)



xy_pop=np.zeros([nPop,nVar])
BestCost=np.zeros(MaxIt)
# BestSol=np.zeros(MaxIt)
## ACOR Main Loop
pp=pop
print('\tMain loop begins...')
for it in range(MaxIt):
    # Means
    print('_____________________')
    xy_pop = np.zeros([nPop, nVar])
    u=np.zeros([nPop, nVar])
    for jj in range(nPop):
        xy_pop[jj, :] = pop[jj]
    
    # Standard Deviations
    sigma = np.zeros([nPop, nVar])
    for jj in range(nPop):
        D = 0
        for r in range(nPop):
            D = D+np.abs(xy_pop[jj, :]-xy_pop[r, :])
        sigma[jj, :] = D*zeta/(nPop-1)
    # Create New Population Array
    emerging_poz=np.zeros([nSample,nVar])
    
    emerging_zed=np.zeros([nSample,1])
    # newpop = np.matlib.repmat(empty_individual, nSample, 1)
    for t  in range(nSample):
        # Initialize Position Matrix
        # emerging_poz = zeros(VarSize)
        # Solution Construction
        for i  in range(nVar):
            # Select Gaussian Kernel
            N_Q=nPop+1
            
            # print('NQ=%.2f'%N_Q)
            while N_Q>nPop-1:
                N_Q = Qmar(pw)
            # print('N_Q=%i'%N_Q)
            # Generate Gaussian Random Variable
            emerging_poz[t,i] = xy_pop[N_Q, i]+sigma[N_Q, i]*np.random.randn()
        # Apply Variable Bounds
        
    emerging_poz2 = limitor(emerging_poz,Hdod)
        # Evaluation
    # Merge Main Population (Archive) and New Population (Samples)
    pop = np.concatenate((emerging_poz2,xy_pop),axis=0) ##ok
    [d51,d2]=np.shape(pop)
    zed_C=np.zeros(d51)
    for hh in range(d51):
        popout=pop[hh,:]
        zed_C[hh] = Hzinh(popout)

    # zed_C=np.concatenate((emerging_zed,xy_pop),axis=0)
    #   # Sort Population
    # [~, SortOrder] = sort([pop.Cost])
    # pUp=np.zeros([d51,2])
    # for hh in range(d51):
    #     pUp[hh,:] = pop[hh,:]
    pop = rdiffH(pop,zed_C)
    # zed_M=np.zeros(d51)
    # for hh in range(d51):
    #     popout=pop[hh,:]
    #     zed_M[hh] = Hzinh(popout)
    # # Delete Extra Members
    # pop = pop[0:nPop-1]
    # Update Best Solution Ever Found
    BestSol = pop[0]# Store Best Cost
    BestCost[it] = Hzinh(BestSol)
    qq=BestCost[it]
    qqev=qq>qq0 and qq>0.56
    qq0=qq
    # Show Iteration Information
    print('Iteration #%i : best ant"s accuracy = %f' %(it+1,qq))
    zman(time.time(),T01)
    T01=time.time()
    if qqev:
        print('\t***New Record***')
        # print('\tWith gamma= %.5f, LR= %.5f,SPW= %.5f :'%(Xh['gamma'],Xh['learning_rate'],Xh['scale_pos_weight']))
        fayl = open('ACO_rekordz7_.txt','a')
        fayl.write('\n__________________________\n')        
        fayl.write('\nn_repeats = %s\n'%str(NR))
        fayl.write('\nisdti = %s\n'%str(isdti))
        fayl.write('\nnpop = %s\n'%str(nPop))
        fayl.write('\n\tAccuracy = %s\n\n'%str(qq))
        fayl.write(str(BestSol))
        fayl.close()
    else:
        print('\t???No record. Accuracy was %0.2f'%(qq*100))
    winsound.Beep(7000, 300)    
    time.sleep(13)
 


#%%Plot
x=range(MaxIt)
plt.figure(1)
plt.plot(BestCost,'b*-')

plt.xlabel('#Iteration')
plt.ylabel('Accuracy')

plt.grid()
# plt.legend()
if isdti==1:
    plt.title('Ant colony raising accuracy of DTI matrices')
    plt.savefig('DTI_ACO68.png',dpi=250)
else:
    plt.title('Raising accuracy of rs-fMRI matrices using Ant colony')
    plt.savefig('RSF_ACO76.png',dpi=250)
winsound.Beep(700, 3000)