# Script Name: GA_XGB11.py
#from numpy import mean
from numpy.random import randint
from numpy.random import rand
import numpy as np
# import copy
import matplotlib.pyplot as plt
from sklearn.model_selection import cross_val_score,RepeatedStratifiedKFold
    
    #train_test_split,\
    #GridSearchCV\
#from skopt.space import Integer,Real
#from skopt.utils import use_named_args
#from skopt import gp_minimize
#from warnings import catch_warnings
#from warnings import simplefilter
from xgboost import XGBClassifier
import pandas as pd
# from pandas.io.excel import ExcelWriter
#from sklearn.metrics import accuracy_score,f1_score,recall_score,precision_score
import time
from datetime import datetime
import winsound
#%%
T00=time.time()

def zman(tn,t0):
    print('__________________________________')
    T03=tn-t0
    H03=int(T03/3600)
    M03=int((T03-H03*3600)/60)
    S03=int(T03-H03*3600-M03*60)
    print('Elapsed %i H %i M %i s'%(H03,M03,S03))
    print(datetime.now().strftime("%D & %H:%M:%S"))
def saat(T03):
    H03=int(T03/3600)
    M03=int((T03-H03*3600)/60)
    S03=int(T03-H03*3600-M03*60)
    return ('%i H %i M %i s'%(H03,M03,S03))
#%%
#%%
isdti=int(input('Use DTIs?  >>>  '))
n_iter=int(input('#iterations ? (df=100) >>>  '))

# bits per variable
n_bits = int(input('#Bit width ? (df=16) >>>  '))
# define the population size
n_pop=int(input('population size [zoj] (df=100)?  >>>  '))
NR=int(input('CV n_repeats  >>>  '))
TT=(n_pop)*NR*n_bits/16
print('Each iteration takes almost %s s. Agree?' %saat(TT))
int(input('a numer: go on    a charactr: no   >>>   '))
agra=int(input('#inital pop ratio ? (d=2) >>>  '))
#%% Importing the excel database
# Vijgz=['Betweenness','CC','CPL','Closeness','Gamma','Lambda','Modularity','SW','EigenValue']
# rz_iter_RS=int(inpTt(' #Excavation points for Random Search  >>>  ')) # 100 iters = 1 minute
# NoRS=int(input(' #Random states?  >>>  '))
if isdti==1:
    hh_X=pd.read_excel(open('Mjazat_STD.xls', 'rb'), sheet_name='X_D', header=0)
else:
    hh_X=pd.read_excel(open('Mjazat_STD.xls', 'rb'), sheet_name='X_R', header=0)
data1_X=pd.DataFrame.to_numpy(hh_X)
#%% Both
#%% Both


data_X=np.array(data1_X)
[r_X,s_X]=np.shape(data_X)
X0_X = data_X[:,0:s_X-1]
X=X0_X.astype('float')
Y0_X = data_X[:,s_X-1]
y=Y0_X.astype('int')


#%% GA
GA_Model=XGBClassifier(use_label_encoder=False,\
            eval_metric='logloss',objective ='binary:logistic')
cv0 = RepeatedStratifiedKFold(n_splits=10, n_repeats=NR, random_state=33)
# genetic algorithm search for continuous function optimization

# from mpl_toolkits.mplot3d import Axes3D
# objective function
def objective(x):
    global X,y,cv0
    # print('\t\tx[0]=%.4f'%x[0])
    GA_Model.learning_rate = x[0]
    GA_Model.scale_pos_weight = x[1]
    GA_Model.colsample_bylevel = x[2]
    GA_Model.colsample_bytree = x[3]
    GA_Model.gamma = x[4]
    GA_Model.max_delta_step = x[5]
    GA_Model.max_depth =int( x[6])
    GA_Model.min_child_weight = x[7]
    GA_Model.n_estimators = int(x[8])
    GA_Model.reg_alpha = x[9]
    GA_Model.reg_lambda = x[10]
    GA_Model.subsample = x[11]

    baseline = cross_val_score(GA_Model, X, y, cv=cv0,scoring='accuracy').mean()
    return baseline

# decode bitstring to numbers
def decode(bounds, n_bits, bitstring):
    decoded = list()
    largest = 2**n_bits
    for i in range(len(bounds)):
        # extract the substring
        start, end = i * n_bits, (i * n_bits)+n_bits
        substring = bitstring[start:end]
        # convert bitstring to a string of chars
        chars = ''.join([str(s) for s in substring])
        # convert string to integer
        integer = int(chars, 2)
        # scale integer to desired range
        value = bounds[i][0] + (integer/largest) * (bounds[i][1] - bounds[i][0])
        # store
        decoded.append(value)
    return decoded

# tournament selection
def selection(pop, scores, k=3):
    # first random selection
    selection_ix = randint(len(pop))
    for ix in randint(0, len(pop), k-1):
        # check if better (e.g. perform a tournament)
        if scores[ix] > scores[selection_ix]:
            selection_ix = ix
    return pop[selection_ix]

# crossover two parents to create two children
def crossover(p1, p2, r_cross):
    # children are copies of parents by default
    c1, c2 = p1.copy(), p2.copy()
    # check for recombination
    if rand() < r_cross:
        # select crossover point that is not on the end of the string
        pt = randint(1, len(p1)-2)
        # perform crossover
        c1 = p1[:pt] + p2[pt:]
        c2 = p2[:pt] + p1[pt:]
    return [c1, c2]

# mutation operator
def mutation(bitstring, r_mut):
    for i in range(len(bitstring)):
        # check for a mutation
        if rand() < r_mut:
            # flip the bit
            bitstring[i] = 1 - bitstring[i]
#%%
# define range for input
ee=1e-6
# bounds = [[ee, 1-ee], [0, 6.0]]
bounds = [[ee, 1-ee], [0, 6.0],[ee, 1-ee],[ee, 1-ee],[ee, 1-ee],\
           [ee, 1-ee],[1, 7],[0, 2],[1, 50],\
            [ee, 1-ee],[ee, 1-ee],[ee, 1-ee]]
# define the total iterations

# n_pp=int(input(' #Lines of 3D plot ? (d=100, not 3d=0) >>>  '))
# crossover rate
r_cross = 0.9
# mutation rate
r_mut = 2.0 / (float(n_bits) * len(bounds))
# genetic algorithm
# initial population of random bitstring
pop = [randint(0, 2, n_bits*len(bounds)).tolist() for _ in range(n_pop)]
# keep track of best solution
#%%
best=0

pop0 = [randint(0, 2, n_bits*len(bounds)).tolist() for _ in range(n_pop*agra)]
decoded0 = [decode(bounds, n_bits, p) for p in pop0]
scores0 = [objective(d) for d in decoded0]
ss=np.argsort(scores0)
sm=[]
for ii in range(n_pop*agra):
    sm.append(pop0[ss[n_pop*agra-1-ii]])
for jj in range(n_pop*(agra-1)):
    sm.pop()
pop=sm
o0 = objective(decode(bounds, n_bits, pop[0]))
print('Creation pool max Accuracy = %f' % (o0))
best, best_eval = pop[0], objective(decode(bounds, n_bits, pop[0]))
#%%
Bala=np.zeros(n_iter)
Vst=np.zeros(n_iter)
# enumerate generations
# mxts=np.zeros([n_iter,2])
# mtz=np.zeros([n_iter])
ii=0
T01=time.time()
for gen in range(n_iter):
    T01=time.time()
    neurekord=0
    # decode population
    decoded = [decode(bounds, n_bits, p) for p in pop]
    # evaluate all candidates in the population
    scores = [objective(d) for d in decoded]
    Bala[gen]=np.amax(scores)
    Vst[gen]=np.mean(scores)
    # check for new best solution
    for i in range(n_pop):
        if scores[i] > best_eval:
            best, best_eval = pop[i], scores[i]
            neurekord=1
            print(">>>%d, new best f(%s) = %f" % (gen,  decoded[i], scores[i]))
    # select parents
    selected = [selection(pop, scores) for _ in range(n_pop)]
    # create the next generation
    children = list()
    for i in range(0, n_pop, 2):
        # get selected parents in pairs
        p1, p2 = selected[i], selected[i+1]
        # crossover and mutation
        for c in crossover(p1, p2, r_cross):
            # mutation
            mutation(c, r_mut)
            # store for next generation
            children.append(c)
    # replace population
    pop = children
    # mxts[ii,:]=decode(bounds, n_bits, best)
    # mtz[ii]=objective(mxts[ii,:])
    decoded2=decode(bounds, n_bits, best)
    ii=ii+1
    #%% Show Iteration Information
    zman(time.time(),T01)
    qq=Bala[gen]
    if neurekord==1 and qq>0.61:
        print('***New Record***')
        print('=> Random search Results at It %i:'%gen)
        # print('\tWith gamma= %.5f, LR= %.5f,SPW= %.5f :'%(Xh['gamma'],Xh['learning_rate'],Xh['scale_pos_weight']))
        print('\tRandom search  Accuracy =  %.5f' %qq)
        fayl = open('Gen_rekordz9.txt','a')
        fayl.write('\n__________________________\n')        
        fayl.write('\nn_repeats = %s\n'%str(NR))
        fayl.write('\nisdti = %s\n'%str(isdti))
        fayl.write('\nn_pop = %s\n'%str(n_pop))
        fayl.write('\n\tAccuracy = %s\n\n'%str(qq))
        fayl.write(str(decoded2))
        fayl.close()
    else:
        print('???No record. Accuracy was %0.2f'%(qq*100))
    winsound.Beep(7000, 300)
    time.sleep(13)
# perform the genetic algorithm search
# best, score = genetic_algorithm(objective, bounds, n_bits, n_iter, n_pop, r_cross, r_mut)
print('All Done!')
decoded = decode(bounds, n_bits, best)
print('f(%s) = %f' % (decoded, best_eval))

#%% Plots
plt.figure(2)
plt.plot(Bala,'r',label='Highest')
plt.plot(Vst,'b',label='Average')
plt.xlabel('#Generation')
plt.ylabel('Accuracy')
plt.title('rs-fMRI accuracy rise using genetic algorithm\nPopulation=400')
plt.grid()
plt.legend()
if isdti==1:
    plt.savefig('DTI_Duwnbe.png',dpi=333)
else:
    plt.savefig('RSF_Duwnbe.png',dpi=333)
winsound.Beep(700, 3000)