# Program Name: Test_Rekordz4.py
from sklearn.model_selection import\
    cross_val_score,\
    RepeatedStratifiedKFold
from xgboost import XGBClassifier
import pandas as pd
import numpy as np
#%% Dialog
isdti=int(input('\nUse DTIs?  >>>  '))
if isdti==1:
    hh_X=pd.read_excel(open('Mjazat_STD.xls', 'rb'), sheet_name='X_D', header=0)
else:
    hh_X=pd.read_excel(open('Mjazat_STD.xls', 'rb'), sheet_name='X_R', header=0)

data1_X=pd.DataFrame.to_numpy(hh_X)
data_X=np.array(data1_X)
[r_X,s_X]=np.shape(data_X)
X0_X = data_X[:,0:s_X-1]
X=X0_X.astype('float')
Y0_X = data_X[:,s_X-1]
y=Y0_X.astype('int')
# NR=int(input('\n\nCV n_repeats  (df=999)>>>  '))
#%%
a=np.zeros([12])
hh=[
{'colsample_bylevel': 0.9948126001908353, 'colsample_bytree': 0.7047431161098624, 'gamma': 0.521494490419371, 'learning_rate': 0.02754453617082988, 'max_delta_step': 0.05402863766180044, 'max_depth': 20, 'min_child_weight': 2.5278528917619507, 'n_estimators': 35, 'reg_alpha': 0.9042514887749212, 'reg_lambda': 3.0284211547646733, 'scale_pos_weight': 0.7915578827199692, 'subsample': 0.42784379138028905},
{'colsample_bylevel': 0.9312986169627607, 'colsample_bytree': 0.44220574866495305, 'gamma': 0.5864259364596154, 'learning_rate': 0.718635582431028, 'max_delta_step': 0.8889366407842187, 'max_depth': 3, 'min_child_weight': 0.946700824589803, 'n_estimators': 1, 'reg_alpha': 1.5127085818017683, 'reg_lambda': 3.0245410228168357, 'scale_pos_weight': 10.089776385241565, 'subsample': 0.8929188572491166},
{'colsample_bylevel': 0.7028585046081564, 'colsample_bytree': 0.909053324697645, 'gamma': 0.8540008084021241, 'learning_rate': 0.16862972479877353, 'max_delta_step': 2.145460199454786, 'max_depth': 55, 'min_child_weight': 0.6687580884336, 'n_estimators': 93, 'reg_alpha': 3.3708914941634327, 'reg_lambda': 3.3941929876099843, 'scale_pos_weight': 0.9872019434607457, 'subsample': 0.39775257253485197},
{'colsample_bylevel': 0.6532017335647236, 'colsample_bytree': 0.9308341508075694, 'gamma': 0.2152703291052973, 'learning_rate': 0.9974347268674156, 'max_delta_step': 1.1171603131984482, 'max_depth': 80, 'min_child_weight': 0.7744208289232635, 'n_estimators': 84, 'reg_alpha': 1.0707973443384586, 'reg_lambda': 1.6818200903844394, 'scale_pos_weight': 2.0333555313758103, 'subsample': 0.981524675228425}
]


s1=len(hh)
Accuz=np.zeros(s1)
for jj in range(s1):
    Test_params = hh[jj]
    Test_Model=XGBClassifier(use_label_encoder=False,\
    colsample_bylevel=Test_params['colsample_bylevel'],\
    colsample_bytree=Test_params['colsample_bytree'],\
    gamma=Test_params['gamma'],\
    learning_rate=Test_params['learning_rate'],\
    max_delta_step=Test_params['max_delta_step'],\
    max_depth=Test_params['max_depth'],\
    min_child_weight=Test_params['min_child_weight'],\
    n_estimators=Test_params['n_estimators'],\
    reg_alpha=Test_params['reg_alpha'],\
    reg_lambda=Test_params['reg_lambda'],\
    subsample=Test_params['subsample'],\
    scale_pos_weight=Test_params['scale_pos_weight'],\
    eval_metric='logloss',objective ='binary:logistic')
    
    cv0 = RepeatedStratifiedKFold(n_splits=10, n_repeats=77, random_state=1)
    #%% Output measures
    Accuz[jj] = cross_val_score(Test_Model, X, y, cv=cv0,scoring='accuracy').mean()
    print('\t%i: Accuracy = %.3f' %(jj,Accuz[jj]))
am=np.argmax(Accuz)

Test_params = hh[am]
Test_Model=XGBClassifier(use_label_encoder=False,\
colsample_bylevel=Test_params['colsample_bylevel'],\
colsample_bytree=Test_params['colsample_bytree'],\
gamma=Test_params['gamma'],\
learning_rate=Test_params['learning_rate'],\
max_delta_step=Test_params['max_delta_step'],\
max_depth=Test_params['max_depth'],\
min_child_weight=Test_params['min_child_weight'],\
n_estimators=Test_params['n_estimators'],\
reg_alpha=Test_params['reg_alpha'],\
reg_lambda=Test_params['reg_lambda'],\
subsample=Test_params['subsample'],\
scale_pos_weight=Test_params['scale_pos_weight'],\
eval_metric='logloss',objective ='binary:logistic')
cv1 = RepeatedStratifiedKFold(n_splits=10, n_repeats=777, random_state=1)
acmac = cross_val_score(Test_Model, X, y, cv=cv1,scoring='accuracy').mean()
print('\t\t%i>>> Best accuracy = %.3f' %(am,acmac))
print(Test_params)