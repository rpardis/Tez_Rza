# Program Name: Test_Final.py
from sklearn.model_selection import\
    cross_val_score,\
    RepeatedStratifiedKFold
from xgboost import XGBClassifier
import pandas as pd
import numpy as np
import winsound
#%% Dialog
isdti=int(input('\nUse DTIs?  >>>  '))
print('\n\n1: Unknown\
\n2: Random Search\n3: GA PC\n4: ACO\n5: Giza')
Algo=int(input('Which Algorithm? >>>    '))
NR=int(input('\n\nCV n_repeats  (df=999)>>>  '))

#%% Importing the excel database


if isdti==1:
    hh_X=pd.read_excel(open('Mjazat_STD.xls', 'rb'), sheet_name='X_D', header=0)
else:
    hh_X=pd.read_excel(open('Mjazat_STD.xls', 'rb'), sheet_name='X_R', header=0)

data1_X=pd.DataFrame.to_numpy(hh_X)
data_X=np.array(data1_X)
[r_X,s_X]=np.shape(data_X)
X0_X = data_X[:,0:s_X-1]
X=X0_X.astype('float')
Y0_X = data_X[:,s_X-1]
y=Y0_X.astype('int')

#%% Testing the model
a=np.zeros([12])
if isdti==0:
    if Algo==1:
        Test_params = 1
    elif Algo==2:
        Test_params = {'colsample_bylevel': 0.9948126001908353, 'colsample_bytree': 0.7047431161098624, 'gamma': 0.521494490419371, 'learning_rate': 0.02754453617082988, 'max_delta_step': 0.05402863766180044, 'max_depth': 20, 'min_child_weight': 2.5278528917619507, 'n_estimators': 35, 'reg_alpha': 0.9042514887749212, 'reg_lambda': 3.0284211547646733, 'scale_pos_weight': 0.7915578827199692, 'subsample': 0.42784379138028905}
    elif Algo==3:
        Test_params = {'learning_rate': 0.25512744287109373, 'scale_pos_weight': 0.6844482421875, 'colsample_bylevel': 0.20648252062988282, 'colsample_bytree': 0.20179808175659178, 'gamma': 0.004609145080566406, 'max_delta_step': 0.7460169640197754, 'max_depth': 5, 'min_child_weight': 1.36688232421875, 'n_estimators': 1, 'reg_alpha': 0.5587462203979492, 'reg_lambda': 0.15576240722656248, 'subsample': 0.2539677772216796}
    elif Algo==4:
        Test_params = {'learning_rate': 0.999999, 'scale_pos_weight': 1.28075188, 'colsample_bylevel': 0.10164594, 'colsample_bytree': 0.47250251, 'gamma': 0.999999, 'max_delta_step': 1.82508585, 'max_depth': 23, 'min_child_weight': 1.73988845, 'n_estimators': 19, 'reg_alpha': 0.7421541, 'reg_lambda': 0.12514671, 'subsample': 0.999999}
    elif Algo==5:
        Test_params = {'learning_rate': 0.634869938, 'scale_pos_weight': 0.84799534, 'colsample_bylevel': 0.104990851, 'colsample_bytree': 0.463480298, 'gamma': 0.240914067, 'max_delta_step': 0.563628211, 'max_depth': 16, 'min_child_weight': 0.805049026, 'n_estimators': 128, 'reg_alpha': 0.636578683, 'reg_lambda': 0.453299139, 'subsample': 0.781000383}
elif isdti==1:        
    if Algo==1:
        Test_params = 1
    elif Algo==2:
        Test_params = {'colsample_bylevel': 0.9465556269207265, 'colsample_bytree': 0.6947085087185831, 'gamma': 0.18905791486990187, 'learning_rate': 0.37335094866663965, 'max_delta_step': 0.8352672071983571, 'max_depth': 35, 'min_child_weight': 0.22474355562854642, 'n_estimators': 67, 'reg_alpha': 2.3957176495906385, 'reg_lambda': 2.0064783039577514, 'scale_pos_weight': 0.7014387825729715, 'subsample': 0.9544222839831399}
    elif Algo==3:
        Test_params = {'learning_rate': 0.5082855058898926, 'scale_pos_weight': 0.932373046875, 'colsample_bylevel': 0.7052608199462891, 'colsample_bytree': 0.12558058282470702, 'gamma': 0.3562014594726562, 'max_delta_step': 0.8997489563598633, 'max_depth': 3, 'min_child_weight': 0.57867431640625, 'n_estimators': 1, 'reg_alpha': 0.938658790649414, 'reg_lambda': 0.9941548954772949, 'subsample': 0.9817800422973633}
    elif Algo==4:
        Test_params = {'learning_rate': 0.999999, 'scale_pos_weight': 0.417476075, 'colsample_bylevel': 0.999999, 'colsample_bytree': 0.152384859, 'gamma': 0.847385059, 'max_delta_step': 1.98221859, 'max_depth': 35, 'min_child_weight': 0.0947457112, 'n_estimators': 10, 'reg_alpha': 0.384692695, 'reg_lambda': 1e-06, 'subsample': 0.994081119}
    elif Algo==5:
        Test_params = {'learning_rate': 0.51323423, 'scale_pos_weight': 0.66804076, 'colsample_bylevel': 0.65473903, 'colsample_bytree': 0.999999, 'gamma': 0.71296939, 'max_delta_step': 0.55870258, 'max_depth': 28, 'min_child_weight': 1.10439356, 'n_estimators': 86, 'reg_alpha': 0.94607546, 'reg_lambda': 0.9521344, 'subsample': 0.999999}
if any(a):
    Test_params = {'learning_rate': a[0], 'scale_pos_weight':a[1] , 'colsample_bylevel':a[2], 'colsample_bytree': a[3], 'gamma':a[4] , 'max_delta_step': a[5], 'max_depth': int(a[6]), 'min_child_weight': a[7], 'n_estimators': int(a[8]), 'reg_alpha': a[9], 'reg_lambda': a[10], 'subsample': a[11]}
#%%
    
Test_Model=XGBClassifier(use_label_encoder=False,\
colsample_bylevel=Test_params['colsample_bylevel'],\
colsample_bytree=Test_params['colsample_bytree'],\
gamma=Test_params['gamma'],\
learning_rate=Test_params['learning_rate'],\
max_delta_step=Test_params['max_delta_step'],\
max_depth=Test_params['max_depth'],\
min_child_weight=Test_params['min_child_weight'],\
n_estimators=Test_params['n_estimators'],\
reg_alpha=Test_params['reg_alpha'],\
reg_lambda=Test_params['reg_lambda'],\
subsample=Test_params['subsample'],\
scale_pos_weight=Test_params['scale_pos_weight'],\
eval_metric='logloss',objective ='binary:logistic')

cv1 = RepeatedStratifiedKFold(n_splits=10, n_repeats=NR, random_state=1402)
cv0 = RepeatedStratifiedKFold(n_splits=10, n_repeats=int(NR/10)+1, random_state=1402)
#%% Output measures
print('\n=> Final Metrics:')
print('________________________________')
Accuracy = cross_val_score(Test_Model, X, y, cv=cv1,scoring='accuracy').mean()
winsound.Beep(600, 5000)
print('\tAccuracy = %.3f' %Accuracy)
Goon=int(input('\n\nGo on other metrics? (df=1) >>>  '))
fayl = open('rekordz_total.txt','a')
fayl.write('\n__________________________\n')        
fayl.write('\n\tn_repeats = %s'%str(NR))
fayl.write('\n\tisdti = %s'%str(isdti))
fayl.write('\n\tAlgo = %s'%str(Algo))

fayl.write('\n\t'+f"Accuracy : {Accuracy:{2}.{3}}")
if Goon==1:
    ROC_AUC = cross_val_score(Test_Model, X, y, cv=cv0,scoring='roc_auc').mean()
    print('ROC_AUC = %.2f' %ROC_AUC)
    rr=f"ROC_AUC : {ROC_AUC:{2}.{3}}"
    Recall = cross_val_score(Test_Model, X, y, cv=cv0,scoring='recall').mean()
    print('Recall = %.2f' %Recall)
    F1_score = cross_val_score(Test_Model, X, y, cv=cv0,scoring='f1').mean()
    print('F1-Score = %.2f' %F1_score)
    Precision = cross_val_score(Test_Model, X, y, cv=cv0,scoring='precision').mean()
    print('Precision = %.2f' %Precision)
    print('********************************')
    print(Test_params)
    print('________________________________')

    fayl.write('\n\t'+f"ROC_AUC : {ROC_AUC:{2}.{2}}")
    fayl.write('\n\t'+f"F1_score : {F1_score:{2}.{2}}")
    fayl.write('\n\t'+f"Precision : {Precision:{2}.{2}}")
    fayl.write('\nTest_params= %s\n'%str(Test_params))
fayl.write('\n..........................\n')
fayl.close()
