# Script Name: Mjazsaz_std.py
import pandas
from sklearn.decomposition import PCA
import pandas as pd
# from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import StandardScaler


R0=pandas.read_excel(open('T_Vijgiz.xlsx', 'rb'),sheet_name='X_R', header=None)
D0=pandas.read_excel(open('T_Vijgiz.xlsx', 'rb'),sheet_name='X_D', header=None)

R1= StandardScaler().fit_transform(R0)
D1= StandardScaler().fit_transform(D0)
# pcaR = PCA(n_components=13).fit_transform(R1)
pcaR = PCA(n_components=78).fit_transform(R1)
pcaD = PCA(n_components=90).fit_transform(D1)

dfR = pd.DataFrame(pcaR)
dfD = pd.DataFrame(pcaD)


with pd.ExcelWriter("Mjazat_std_0.xlsx") as writer:
    dfR.to_excel(writer,sheet_name='X_R')
    dfD.to_excel(writer,sheet_name='X_D')
print('Do:\n1-\tdel 1st col\n2-\tCorrect last col\n3-\tSheet name')

#%% Plots
plt.figure(2)
plt.plot(np.var(pcaR,0),'b',label='rs-fMRI')
plt.plot(np.var(pcaD,0),'r',label='DTI')
plt.xlabel('Component order')
plt.title('Variances after PCA\n13-component mode')
plt.ylabel('Variance')
plt.grid()
plt.legend()
plt.savefig('Varz_C.png',dpi=333)
#%%
plt.figure(2)
plt.plot(np.var(pcaR,0),'b',label='rs-fMRI')
plt.plot(np.var(pcaD,0),'r',label='DTI')
plt.xlabel('Component order')
plt.title('Variances after PCA\n13-component mode')
plt.ylabel('Variance')
plt.grid()
plt.legend()
plt.savefig('Varz_C.png',dpi=333)