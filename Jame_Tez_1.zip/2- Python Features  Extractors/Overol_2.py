# File name: Overol_2.py
import scipy.io as sio
import numpy as np
#from Twabe import threshold_p
import time
import scipy.stats as scs
from networkx import from_numpy_array as npx
# import matplotlib.pyplot as pp
from networkx import is_connected as detco
from sklearn.preprocessing import StandardScaler as yekke
from sklearn.decomposition import PCA as sklearnPCA
import pandas as pd
from random import randint as randi
# from numpy import concatenate as cat
# import numpy as np
#import openpyxl
#from skopt.space import Integer,Real
#from skopt.utils import use_named_args
#from skopt import gp_minimize
#from warnings import catch_warnings
#from warnings import simplefilter
from xgboost import XGBClassifier
from scipy.stats import uniform
# import pandas as pd
# import numpy as np
# from pandas.io.excel import ExcelWriter
#from sklearn.metrics import accuracy_score,f1_score,recall_score,precision_score
# import time
from sklearn.model_selection import cross_val_score,\
    RepeatedStratifiedKFold,RandomizedSearchCV\
    #train_test_split,\
    #GridSearchCV\
#%%
def threshold_p(W, p, copy=True):

    if p > 1 or p < 0:
        raise Exception('XTA001: Threshold must be in range [0,1]')
    if copy:
        W = W.copy()
    n = len(W)	# number of nodes
    np.fill_diagonal(W, 0)	# clear diagonal

    if np.allclose(W, W.T):	# if symmetric matrix
        W[np.tril_indices(n)] = 0	# ensure symmetry is preserved
        ud = 2	# halve number of removed links
    else:
        ud = 1

    ind = np.where(W)	# find all links

    I = np.argsort(W[ind])[::-1]	# sort indices by magnitude

    en = int(round((n * n - n) * p / ud))	# number of links to be preserved

    W[(ind[0][I][en:], ind[1][I][en:])] = 0  # apply threshold
    #W[np.ix_(ind[0][I][en:], ind[1][I][en:])]=0

    if ud == 2:	# if symmetric matrix
        W[:, :] = W + W.T	# reconstruct symmetry

    return W
#%%
#%%---------------
isdti=int(input(' Use DTIs?  >>>  '))
H=sio.loadmat('chargruh.mat')
#%%
T0=time.time()
PP=H['RSF_TDC']
QQ=H['RSF_ASD']
RR=H['DTI_TDC']
SS=H['DTI_ASD']
s_p=np.shape(PP)[2]
s_q=np.shape(QQ)[2]
s_r=np.shape(RR)[2]
s_s=np.shape(SS)[2]
print('#RSF_TDC (P) = %i' %s_p)
print('#RSF_ASD (Q) = %i' %s_q)
print('#DTI_TDC (R) = %i' %s_r)
print('#DTI_ASD (S) = %i' %s_s)
T1=time.time()
#%%
azma='0'#input('0:Normal 1:Trial >>> ')
if azma=='1':
    rr=9
    print('Trial mode')
else:
    rr=1
    print('Full mode')
# kutah=input('abrev for feature >>> ')

if isdti==0:
    sps=np.arange (0.15, 0.321, 0.01*rr)
    sps_plot=np.arange (0.15, 0.321, 0.01*2*rr)
    unw='RSF'
else:
    sps=np.arange (0.06, 0.071, 0.005*rr)
    sps_plot=np.arange (0.06, 0.071, 0.005*2*rr)
    unw='DTI'
    PP=RR
    QQ=SS
    s_p=s_r
    s_q=s_s
# s_p=2
# s_q=3
gaamha=np.shape(sps)[0]
#%%
print('No.\tFeature\ttype\tpv(percent)\telapse(s)')
print('============================================')
#%%
vv={\
1:	'connected_double_edge_swap',\
2:	'average_clustering',\
3:	'estrada_index',\
4:	'degree_centrality',\
5:	'graph_clique_number',\
6:	'graph_number_of_cliques',\
7:	'core_number',\
8:	'average_neighbor_degree',\
9:	'katz_centrality_numpy',\
10:	'eigenvector_centrality_numpy',\
11:	'subgraph_centrality',\
12:	'large_clique_size',\
13:	'triangles',\
14:	'clustering',\
15:	'subgraph_centrality_exp',\
16:	'transitivity',\
17:	'number_of_cliques',\
18:	'node_clique_number',\
19:	'edge_connectivity',\
20:	'pagerank',\
21:	'current_flow_closeness_centrality',\
22:	'information_centrality',\
23:	'second_order_centrality',\
24:	'load_centrality',\
25:	'betweenness_centrality',\
26:	'wiener_index',\
27:	'radius',\
28:	'average_shortest_path_length',\
29:	'diameter',\
30:	'global_efficiency',\
31:	'closeness_centrality',\
32:	'square_clustering',\
33:	'eccentricity',\
34:	'harmonic_centrality',\
35:	'approximate_current_flow_betweenness_centrality',\
36:	'node_connectivity',\
37:	'current_flow_betweenness_centrality',\
38:	'local_efficiency',\
39:	'effective_size',\
40:	'constraint',\
}
# print(vv)
# fn=int(input('Which feature?   >>>   '))
X_std=np.zeros([s_p+s_q,1])
for fn in range(1,3):
    # print(fn)
    
    #++++++++++++++++++++++++++++++++++++++++++++++
    jj=vv[fn]
    kuth=jj[0].upper()+jj[1]+'.'
    ii=0
    for kk in jj:
        if kk=='_':
            # print(jj[ii+1])
            kuth=kuth+jj[ii+1].lower()+'.'
        ii+=1
    #print('Find plot as',kuth,'\b.png')
    #%%
    if fn==1:
        from networkx import connected_double_edge_swap as cac
    elif fn==2:
        from networkx.algorithms.approximation import average_clustering as cac
    elif fn==3:
        from networkx import estrada_index as cac
    elif fn==4:
        from networkx import degree_centrality as cac
    elif fn==5:
        from networkx import graph_clique_number as cac
    elif fn==6:
        from networkx import graph_number_of_cliques as cac
    elif fn== 7 :
        from networkx import core_number as cac
    elif fn== 8 :
        from networkx import average_neighbor_degree as cac
    elif fn== 9 :
        from networkx import katz_centrality_numpy as cac
    elif fn== 10 :
        from networkx import eigenvector_centrality_numpy as cac
    elif fn== 11 :
        from networkx import subgraph_centrality as cac
    elif fn== 12 :
        from networkx.algorithms.approximation import large_clique_size as cac
    elif fn== 13 :
        from networkx import triangles as cac
    elif fn== 14 :
        from networkx import clustering as cac
    elif fn== 15 :
        from networkx import subgraph_centrality_exp as cac
    elif fn== 16 :
        from networkx import transitivity as cac
    elif fn== 17 :
        from networkx import number_of_cliques as cac
    elif fn== 18 :
        from networkx import node_clique_number as cac
    elif fn== 19 :
        from networkx import edge_connectivity as cac
    elif fn== 20 :
        from networkx import pagerank as cac
    elif fn== 21 :
        from networkx import current_flow_closeness_centrality as cac
    elif fn== 22 :
        from networkx import information_centrality as cac
    elif fn== 23 :
        from networkx import second_order_centrality as cac
    elif fn== 24 :
        from networkx import load_centrality as cac
    elif fn== 25 :
        from networkx import betweenness_centrality as cac
    elif fn== 26 :
        from networkx import wiener_index as cac
    elif fn== 27 :
        from networkx import radius as cac
    elif fn== 28 :
        from networkx import average_shortest_path_length as cac
    elif fn== 29 :
        from networkx.algorithms import diameter as cac
    elif fn== 30 :
        from networkx import global_efficiency as cac
    elif fn== 31 :
        from networkx import closeness_centrality as cac
    elif fn== 32 :
        from networkx import square_clustering as cac
    elif fn== 33 :
        from networkx import eccentricity as cac
    elif fn== 34 :
        from networkx import harmonic_centrality as cac
    elif fn== 35 :
        from networkx import approximate_current_flow_betweenness_centrality as cac
    elif fn== 36 :
        from networkx import node_connectivity as cac
    elif fn== 37 :
        from networkx import current_flow_betweenness_centrality as cac
    elif fn== 38 :
        from networkx import local_efficiency as cac
    elif fn== 39 :
        from networkx import effective_size as cac
    elif fn== 40 :
        from networkx import constraint as cac

#%%
    ss=sps[0]
    aa=PP[:,:,1]
    th=threshold_p(aa,sps[0])
    th[th != 0] = 1
    B_Vjs=cac(npx(th))
    oia=(type(B_Vjs)==float or type(B_Vjs)==int)
    pvv=np.zeros([gaamha])
    
    if oia:
        #print('Output of the algorithm is a floating point or an integer')
        tdc_kM=np.zeros([s_p,gaamha])
        asd_kM=np.zeros([s_q,gaamha])
        tdc_g=np.zeros([s_p])
        asd_g=np.zeros([s_q])
        
        ii=0
        for gaam in range(gaamha):
        # print('%.3f of %.3f'%(sps[gaam],sps[gaamha-1]))
            for fard in range(s_p):
                aa=PP[:,:,fard]
                th=threshold_p(aa,sps[gaam])
                th[th != 0] = 1
                isco=detco(npx(th))
                if isco==0:
                    fard2=fard-1
                    aa=PP[:,:,fard2]
                    th=threshold_p(aa,sps[gaam])
                    th[th != 0] = 1
                B_Vjs=cac(npx(th))           
                tdc_kM[fard,gaam]=np.array(B_Vjs)
            for fard in range(s_q):
                aa=QQ[:,:,fard]
                th=threshold_p(aa,sps[gaam])
                th[th != 0] = 1
                isco=detco(npx(th))
                if isco==0:
                    fard2=fard-1
                    aa=QQ[:,:,fard2]
                    th=threshold_p(aa,sps[gaam])
                    th[th != 0] = 1            
                B_Vjs=cac(npx(th))
                asd_kM[fard,gaam]=np.array(B_Vjs)
            tdc_g[:]=tdc_kM[:,gaam]
            asd_g[:]=asd_kM[:,gaam]
            pvv[ii]=scs.ttest_ind(tdc_g.T,asd_g.T)[1]
            ii=ii+1
        tdc_M=np.mean(tdc_kM,1)
        asd_M=np.mean(asd_kM,1)
        vijdo=np.append(tdc_M,asd_M,axis=0)
        vijse = yekke().fit_transform(np.reshape(vijdo,[s_p+s_q,1]))
        X_std=np.append(X_std,vijse,axis=1)
        # med_PP=np.median(cc_PP,0)
        # med_QQ=np.median(cc_QQ,0)
        tt2=scs.ttest_ind(tdc_M.T,asd_M.T)[1]
        pv=np.mean(tt2)
        titr= 'Overall TTest2 for the '+unw +' '+ kuth
    
    #%%
    else:
        #print('Output of the algorithm is a dictionary')
        tdc_kM=np.zeros([264,s_p,gaamha])
        asd_kM=np.zeros([264,s_q,gaamha])
        tdc_3=np.zeros([264])
        asd_3=np.zeros([264])
        for gaam in range(gaamha):
            # print('%.3f of %.3f'%(sps[gaam],sps[gaamha-1]))
            for fard in range(s_p):
                aa=PP[:,:,fard]
                th=threshold_p(aa,sps[gaam])
                th[th != 0] = 1
                isco=detco(npx(th))
                if isco==0:
                    fard2=fard-1
                    aa=PP[:,:,fard2]
                    th=threshold_p(aa,sps[gaam])
                    th[th != 0] = 1
                B_Vjs=cac(npx(th))
                bHp=np.array(list(B_Vjs.items()))
                tdc_kM[:,fard,gaam]=bHp[:,1]
            for fard in range(s_q):
                aa=QQ[:,:,fard]
                th=threshold_p(aa,sps[gaam])
                th[th != 0] = 1
                isco=detco(npx(th))
                if isco==0:
                    fard2=fard-1
                    aa=QQ[:,:,fard2]
                    th=threshold_p(aa,sps[gaam])
                    th[th != 0] = 1 
                B_Vjs=cac(npx(th))
                bHp=np.array(list(B_Vjs.items()))
                asd_kM[:,fard,gaam]=bHp[:,1]
        tdc_M=np.mean(tdc_kM,2)
        asd_M=np.mean(asd_kM,2)
        vijdo=np.append(tdc_M.T,asd_M.T,axis=0)
        vijse = (yekke().fit_transform(vijdo.T)).T
        X_std=np.append(X_std,vijse,axis=1)
        if any(np.amax(tdc_M,0)-np.amin(tdc_M,0)<1e-6) or any(np.amax(asd_M,0)-np.amin(asd_M,0)<1e-6):
            print('XXXXXXXXXXX')
            raise SystemExit('Equity !')
        # med_PP=np.median(cc_PP,0)
        # med_QQ=np.median(cc_QQ,0)
        tt2=scs.ttest_ind(tdc_M.T,asd_M.T)[1]
        pv=np.mean(tt2)
        pvvv=np.zeros([gaamha,264]) 
        for gaam in range(gaamha):
            for nqt in range(264):
                tdc_3=tdc_kM[nqt,:,gaam]
                asd_3=asd_kM[nqt,:,gaam]
                pvvv[gaam,nqt]=scs.ttest_ind(tdc_3.T,asd_3.T)[1]
        pvn=np.mean(pvvv,0)
        mn=np.argmin(pvn)
        mn1=np.int(np.floor(mn/264))
        nqth=np.int(mn-mn1*264)
        pvv=pvvv[:,nqth]
        nogg=' for point #'
        titr= 'TTest2 '+unw +' '+ kuth+nogg+str(nqth)
    T2=time.time()
    tt=T2-T1
    if oia:
        print('%i]\t%s\tnumber\t%0.2f\t%.4f'%(fn,kuth,pv*100,tt))
    else:
        print('%i]\t%s\tdict\t%0.2f\t%.4f'%(fn,kuth,pv*100,tt))
    T1=T2 
#%%
#%% Exporting the excel database
df = pd.DataFrame(X_std)
if isdti==1:
    with pd.ExcelWriter("U_Vijgiz.xls") as writer:
        df.to_excel(writer,sheet_name='X_D')
else:
    with pd.ExcelWriter("U_Vijgiz.xls") as writer:
        df.to_excel(writer,sheet_name='X_R')   
